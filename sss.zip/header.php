<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8">
<title><?php bloginfo('name'); ?> <?php if ( is_single() ) { ?> &raquo; Blog Archive <?php } ?> <?php wp_title(); ?></title>
<meta name="viewport" content="width=device-width, maximum-scale=1.0, minimum-scale=1.0" />


<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<meta name="description" content="<?php bloginfo('description') ?>" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />


<link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/favicon/favicon.ico"/>
<link rel="apple-touch-icon" sizes="57x57" href="<?php bloginfo('template_url'); ?>/favicon/apple-icon-57x57.png"/>
<link rel="apple-touch-icon" sizes="60x60" href="<?php bloginfo('template_url'); ?>/favicon/apple-icon-60x60.png"/>
<link rel="apple-touch-icon" sizes="72x72" href="<?php bloginfo('template_url'); ?>/favicon/apple-icon-72x72.png"/>
<link rel="apple-touch-icon" sizes="76x76" href="<?php bloginfo('template_url'); ?>/favicon/apple-icon-76x76.png"/>
<link rel="apple-touch-icon" sizes="114x114" href="<?php bloginfo('template_url'); ?>/favicon/apple-icon-114x114.png"/>
<link rel="apple-touch-icon" sizes="120x120" href="<?php bloginfo('template_url'); ?>/favicon/apple-icon-120x120.png"/>
<link rel="apple-touch-icon" sizes="144x144" href="<?php bloginfo('template_url'); ?>/favicon/apple-icon-144x144.png"/>
<link rel="apple-touch-icon" sizes="152x152" href="<?php bloginfo('template_url'); ?>/favicon/apple-icon-152x152.png"/>
<link rel="apple-touch-icon" sizes="180x180" href="<?php bloginfo('template_url'); ?>/favicon/apple-icon-180x180.png"/>
<link rel="icon" type="image/png" sizes="192x192" href="<?php bloginfo('template_url'); ?>/favicon/android-icon-192x192.png"/>
<link rel="icon" type="image/png" sizes="32x32" href="<?php bloginfo('template_url'); ?>/favicon/favicon-32x32.png"/>
<link rel="icon" type="image/png" sizes="96x96" href="<?php bloginfo('template_url'); ?>/favicon/favicon-96x96.png"/>
<link rel="icon" type="image/png" sizes="16x16" href="<?php bloginfo('template_url'); ?>/favicon/favicon-16x16.png"/>
<link href="<?php bloginfo('template_url'); ?>/css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all" />
<link href="<?php bloginfo('template_url'); ?>/css/webslidemenu.css" rel="stylesheet" type="text/css" media="all" />
<link href="<?php bloginfo('template_url'); ?>/swiper/swiper.min.css" rel="stylesheet" type="text/css" media="all" />

<link href="<?php bloginfo('template_url'); ?>/css/animations.css" rel="stylesheet" type="text/css" media="all" />
<link href="<?php bloginfo('template_url'); ?>/css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="<?php bloginfo('template_url'); ?>/css/responsive.css" rel="stylesheet" type="text/css" media="all" />



<?php wp_head() ?>
</head>

<body <?php body_class(); ?>>
<header>
	<div class="container">
		<div class="row">
			<div class="col-12">
				<a href="<?php echo get_settings('home'); ?>" class="sleep-study-specialists" title="<?php bloginfo('name'); ?>"><img src="<?php echo get_field('logo_img','option'); ?>" alt="<?php bloginfo('name'); ?>"></a>
				<div class="navigation">
					<div class="wsmenucontainer clearfix">
						<div class="wsmobileheader clearfix">
							<a id="wsnavtoggle" class="animated-arrow"><span></span></a>
						</div>
						<div class="overlapblackbg"></div>
						<div class="wsmain">
							<nav class="wsmenu clearfix">
								<?php wp_nav_menu( array( 'theme_location' => 'main-menu', 'menu_class' => 'mobile-sub wsmenu-list' ) ); ?>
							</nav>

						</div>
					</div>
				</div>
			</div>


		</div>
		</div>

	<div class="curve"><img src="<?php bloginfo('template_url'); ?>/images/curve.png" alt="curve" /></div>
</header>
