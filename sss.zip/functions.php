<?php
	if ( function_exists('register_sidebar') )
		register_sidebar(array(
			'before_widget' => '<div class="sidepanel">',
			'after_widget' => '</div>',
			'before_title' => '<h3>',
			'after_title' => '</h3>',
	));

	add_theme_support( 'post-thumbnails', array( 'post', 'page' ) );

	function empty_content($str) {
		return trim(str_replace('&nbsp;','',strip_tags($str))) == '';
	}

	function register_my_menu() {
	  register_nav_menu('main-menu',__( 'Primary Navigation' ));
	  register_nav_menu('footer-menu',__( 'Footer Menu 1' ));
		 register_nav_menu('footer-menu-2',__( 'Footer Menu 2' ));
	}
	add_action( 'init', 'register_my_menu' );
