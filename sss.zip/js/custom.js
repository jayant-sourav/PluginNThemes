$(window).ready(function(){
	"use strict";
  	$('#ddmenu li').hover(function () {
		 clearTimeout($.data(this,'timer'));
		 $('ul',this).stop(true,true).slideDown(200);		
	}, function () {
	$.data(this,'timer', setTimeout($.proxy(function() {
		  $('ul',this).stop(true,true).slideUp(200);
		}, this), 100));
		
	});
 	
	$('.yes-btn').click(function(){
		$('.yes-no-div,.yes-div').slideToggle();
	});
	$('.no-btn').click(function(){
		$('.yes-no-div,.no-div').slideToggle();
	});
	
	var wow = new WOW({
		animateClass: 'animated',
		offset: 120
	});
	wow.init();
	
	highdpi_init();
});


 
$(window).load(function() {
	"use strict";
	 adjustHeightWidth();
});

$(window).resize(function() {
	"use strict";
	adjustHeightWidth();
});
function adjustHeightWidth(){
	"use strict";
	$('.playback-div iframe').css({'height':$('.playback-div').width()/1.77944862155}); 
}

//Retina Graphics 
function highdpi_init(){
	"use strict";
	$(".replace-2x").each(function (){
        if ($(this).css("font-size") == "1px") {           
            var src = $(this).attr("src");
            $(this).attr("src", src.replace(/(@2x)*.png/i, "@2x.png").replace(/(@2x)*.jpg/i, "@2x.jpg"));			
        }
	});
}

