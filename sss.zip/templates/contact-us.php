
<?php
/*
Template Name: Contact Us
*/
get_header();
the_post();
?>


<section class="innerpages">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<h2><?php echo get_field('sub_title'); ?></h2>
			</div>
		</div>
	</div>
</section>
<section class="contact-container">
	<div class="container">
		<form>
		<div class="row">



						  <?php echo do_shortcode('[contact-form-7 id="96" title="Contact form 1"]'); ?>
		</div>
		<form>
			<div class="row billing-physician">
				<div class="col-lg-8 col-md-8 col-sm-7 col-xs-12 billing">
					<p><?php echo get_field('contact_detail'); ?></p>
				</div>
				
					<div class="col-lg-4 col-md-4 col-sm-5 col-xs-12">
					<img src="<?php echo get_field('contact_image'); ?>" alt="<?php echo get_sub_field('title'); ?>" />
				</div>
			</div>
	</div>
</section>


<?php get_footer() ?>
