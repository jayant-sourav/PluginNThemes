<?php
/*
Template Name: Home Page
*/
get_header('home');
the_post();
?>

<?php the_content(); ?>

<section class="testimonials-main">
	<div class="container clearfix">
		<div class="testimonials-container">
			<div class="swiper-wrapper">
					<?php
							 if( have_rows('carousel_detail_with_name') ):
							 while( have_rows('carousel_detail_with_name') ): the_row();
					 ?>
					 <div class="swiper-slide" data-swiper-autoplay="7000">
	 					<div class="testimonials">
					 <p><?php echo get_sub_field('detail'); ?></p>
						<div class="client-name">-<?php echo get_sub_field('name'); ?></div>

				</div>
			</div>
			<?php
				endwhile;
			endif;
			?>


			</div>
			<!-- start Pagination -->
			<div class="swiper-pagination"></div>
			<!-- end Pagination -->
		</div>
	</div>
</section>

<?php get_footer() ?>
