<?php
/*
Template Name: About Page
*/
get_header();
the_post();
?>



<section class="aboutuspage">
	<div class="container">
		<div class="row">
			<div class="col-12 formobile">
				<h1><?php the_title(); ?></h1>
			</div>


			<div class="col-12">

				<h2 class="padding-bottom54"><?php echo get_field('sub_title'); ?></h2>
<?php the_content(); ?>
<h2 class="text-center padding-top78 padding-bottom41"><?php echo get_field('title_2'); ?></h2>


<div class="playback-div"><iframe width="100%" height="auto" src="<?php echo get_field('video_box'); ?>" frameborder="0" allowfullscreen></iframe></div>


			</div>
		</div>
	</div>
</section>
<section class="aboutuspage blue-container">
	<div class="container">
		<div class="row">
			<div class="col-12">

				<?php
						if( have_rows('box2_image_with_title') ):
						while( have_rows('box2_image_with_title') ): the_row();
				?>
						<h3><?php echo get_sub_field('title'); ?></h3>
						<div class="row night-time">
						<?php
							if( have_rows('image') ):
								while( have_rows('image') ): the_row();
							?>
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
								<div class="icon-main">
									<div class="icon-holder"><img src="<?php echo get_sub_field('image'); ?>" alt="<?php echo get_sub_field('title'); ?>"/></div>
									<h4><?php echo get_sub_field('title'); ?></h4>
								</div>
							</div>
							<?php
								endwhile;
							endif;
						?>
					</div>
					<p>&nbsp;<br /></p>
				<?php
						endwhile;
						endif;
					?>

				<div class="text-align-center padding-top88">
					<p><?php echo get_field('detail_7'); ?></p>
				</div>
			</div>
		</div>
	</div>
</section>


<section class="aboutuspage">
	<div class="container">
		<div class="row">
			<div class="col-12">

				<h2><?php echo get_field('contact_title'); ?></h2>
      <?php echo get_field('contact_detail'); ?>

				<h4 class="padding-top52 padding-bottom54"><?php echo get_field('contact_button_heading'); ?></h4>
				<div class="contact-us-btn">
					<a href="<?php echo get_field('contact_link'); ?>" class="button"><?php echo get_field('contact_link_text'); ?></a>
				</div>
			</div>
		</div>
	</div>
</section>
<?php get_footer() ?>
