<?php
/*
Template Name: for patients
*/
get_header();
the_post();
?>
<div id="post-<?php the_ID(); ?>" class="post">

<section class="innerpages padding-bottom95">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<h2><?php echo get_field('sub_title'); ?></h2>
				<?php the_content(); ?>
			</div>
		</div>
	</div>
</section>

<section class="blue-container  innerpages">
	<div class="container">
		<div class="row">

			<?php
				if( have_rows('title_2') ):
					while( have_rows('title_2') ): the_row();
			?>
					<div class="col-12">
						<h3><?php echo get_sub_field('heading'); ?></h3>
					</div>
							<?php
									if( have_rows('steps') ):
									while( have_rows('steps') ): the_row();
							?>
							<div class="col-12 steps-div">
								<div class="icon-step"><div><img src="<?php echo get_sub_field('image'); ?>" alt="<?php echo get_sub_field('title'); ?>"/></div></div>



								<div class="step-detail">
									<h5><strong><?php echo get_sub_field('title'); ?></h5>
									<p></strong>	<?php echo get_sub_field('detail'); ?></p>
								</div>
							</div>
						<?php
					endwhile;
				endif;
				?>
			<?php
		endwhile;
	endif;
	?>
		</div>
	</div>
</section>


<section class="innerpages">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="contact-text">


					<h2><?php echo get_field('title_3'); ?></h2>
					<p><?php echo get_field('detail_3'); ?></p>
				</div>
				<div class="contact-us-btn">
					<a href="<?php echo get_field('contact_link'); ?>" class="button"><?php echo get_field('conatact_link_text'); ?></a>
				</div>

			</div>
		</div>
	</div>
</section>
</div>
<?php get_footer() ?>
