<?php
/*
Template Name: Contact Us
*/
get_header();
the_post();
?>
<div id="post-<?php the_ID(); ?>" class="post">

<section class="innerpages">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<h3><?php the_content(); ?> </h3>

			</div>
		</div>
	</div>
</section>
<section class="blue-container">
	<div class="container">

		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">

					<div class="col-12">
						<h2>	<?php
									if( have_rows('title_2') ):
										while( have_rows('title_2') ): the_row();
								?>
										<?php echo get_sub_field('heading'); ?>

												<?php
														if( have_rows('steps') ):
														while( have_rows('steps') ): the_row();
												?>
												<?php echo get_sub_field('title'); ?>
												<img src="<?php echo get_sub_field('image'); ?>" class="about-img" alt="<?php echo get_sub_field('detail'); 	?>" />
												<?php echo get_sub_field('detail'); ?>

													<?php
												endwhile;
											endif;
											?>
										<?php
									endwhile;
								endif;
								?>

				</h2>
					</div>
				</div>
			</div>
</div>
</section>

<section class="innerpages">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="contact-text">
					<p><?php echo get_field('title_3'); ?> </p>
				</div>
				<div class="contact-us-btn">
					<a href="contact-us.html" class="button">Contact Us</a>
				</div>
			</div>
		</div>
	</div>
</section>
</div>
