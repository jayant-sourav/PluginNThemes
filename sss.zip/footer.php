
<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">

<a href="<?php echo get_settings('home'); ?>" class="foot-sleep-study-specialists" title="<?php bloginfo('name'); ?>"><img src="<?php echo get_field('footer_logo','option'); ?>" alt="<?php bloginfo('name'); ?>"></a>


				<div class="foot-address">

<p><a class="google-map" href="<?php echo get_field('footer_address_map','option'); ?>" target="_blank"><?php echo get_field('footer_address','option'); ?></a></p>

					<p><a href="tel:<?php echo get_field('footer_number','option'); ?>" class="link"><?php echo get_field('footer_number','option'); ?></a></p>
					<p><a href="mailto:<?php echo get_field('footer_mail','option'); ?>" class="link"><?php echo get_field('footer_mail','option'); ?></a></p>

				</div>
			</div>

			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 foot-right">
				<div class="foot-right-div">

					<ul><li><?php wp_nav_menu(array( 'theme_location' =>'footer-menu' ) ); ?></li></ul>
					<ul><li><?php wp_nav_menu(array( 'theme_location' =>'footer-menu-2' ) ); ?></li></ul>

					<p class="copyright"><?php echo get_field('footer_text','option'); ?></p>
				</div>
			</div>
		</div>
	</div>
</footer>
<script src="<?php bloginfo('template_url'); ?>/js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="<?php bloginfo('template_url'); ?>/js/webslidemenu.js" type="text/javascript"></script>
<script src="<?php bloginfo('template_url'); ?>/swiper/swiper.min.js" type="text/javascript"></script>
<script src="<?php bloginfo('template_url'); ?>/swiper/swiper.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/css3-animate-it.js"></script>

<script src="<?php bloginfo('template_url'); ?>/js/custom.js" type="text/javascript"></script>

<!--end swiper-->



<?php wp_footer() ?>
<script>
var $ = jQuery.noConflict();
</script>
</body>
</html>
