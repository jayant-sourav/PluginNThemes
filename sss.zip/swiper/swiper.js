$(window).load(function() {
	"use strict";
    var swiper = new Swiper('.testimonials-container', {
		pagination: '.swiper-pagination',
        paginationClickable:true,
		autoplay: true,
		speed:1000,
        slidesPerView:1,
        spaceBetween:0,
		autoHeight:true,
		effect: 'slide'
    });
	 
});