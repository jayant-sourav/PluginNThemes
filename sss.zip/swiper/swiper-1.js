$(window).load(function() {
	/* var flag=0; */
	var perView;
	var desktop;
	var tablet;
	var minitablet;
	var mobile;
	if(ajaxpagination.flag == 1){ /* 4,5,6 */
		perView = 2
		desktop = 2;
		tablet = 2;
		minitablet = 2;
		mobile = 1;
	}
	else{/* 1,2,3,7 */
		perView = 4
		desktop = 4;
		tablet = 3;
		minitablet = 2;
		mobile = 1;
	}
    var swiper = new Swiper('.swiper-container', {         
        paginationClickable:true,
        slidesPerView:perView,
		nextButton:'.swiper-button-next',
        prevButton:'.swiper-button-prev',
        spaceBetween:1,
        breakpoints:{
            1024:{
                slidesPerView:desktop,
                spaceBetween: 1
            },
            768:{
                slidesPerView: tablet,
                spaceBetween: 1
            },
            640:{
                slidesPerView:minitablet,
                spaceBetween: 1
            },
            414:{
                slidesPerView: mobile,
                spaceBetween: 1
            }
        }
    });
	var swiper = new Swiper('.gallery-container', {         
        paginationClickable:true,
        slidesPerView:1,
		nextButton:'.swiper-button-next',
        prevButton:'.swiper-button-prev',
        spaceBetween:0
    });
});