<?php 
	// check for rows (parent repeater)
	if( have_rows('box_2') ): ?>
		<?php 
			// loop through rows (parent repeater)
			while( have_rows('box_2') ): the_row(); ?>
				<?php the_sub_field('box_2_heading'); ?>
                <?php the_sub_field('box_2_small_header'); ?>
				<?php 
					// check for rows (sub repeater)
					if( have_rows('assets_from') ): ?>
						<?php 
							// loop through rows (sub repeater)
							while( have_rows('assets_from') ): the_row();
						?>
                                <img src="<?php the_sub_field('image'); ?>" alt="image1" /></div>
                                <?php the_sub_field('title'); ?>
                                <?php the_sub_field('detail'); ?>
					<?php endwhile; ?>
				<?php endif; //if( get_sub_field('items') ): ?>
		<?php endwhile; // while( has_sub_field('to-do_lists') ): ?>
<?php endif; // if( get_field('to-do_lists') ): ?>