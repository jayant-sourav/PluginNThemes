
<?php
/*
  Plugin Name: Limit Excerpt.
  Author: JSourav
  Version:1.11
  Description: This Plugin will going to return content of Excerpt to particular length of Charaters(Not Words) with echo get_excerpt($x). Parameter/Argument ($x) passed will be integer e.g <?php echo get_excerpt(76); ?> to get specifc character length up to 76 Characters.
*/
function get_excerpt($count){
  $permalink = get_permalink($post->ID);
  $excerpt = get_the_content();
  $excerpt = strip_tags($excerpt);
  $excerpt = substr($excerpt, 0, $count);
  $excerpt = $excerpt.'... <a href="'.$permalink.'">more</a>';
  return $excerpt;
}
?>