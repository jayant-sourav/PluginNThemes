

This Plugin will going to return content of Excerpt to particular length of Charaters(Not Words) with passing value in function. Parameter/Argument passed will be integer.
e.g <?php echo get_excerpt(76); ?> to get specifc character length up to 76 Characters.

Best part of this plugin is you can use it according to your requirement, not for specefic Page or Post.