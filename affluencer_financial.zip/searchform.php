<form role="search" method="get" class="search-form" action="<?php echo home_url( '/' ); ?>">
	<div class="blogSeach">
        <input type="search" class="search-field" name="s" placeholder="Enter the keyword..." type="text" value="<?php echo esc_attr( $_GET['s'] ); ?>">
	</div>
</form>
