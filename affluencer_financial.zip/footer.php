<footer class="graybg whitebg">
  <div class="footertoppart">
    <div class="footerpart padTB30">
      <div class="container ">
        <div class="row">
          <div class="col-md-2 col-sm-6 mrgformobile">
            <div class="clearfix">
              <h3>QUICK LINK</h3>
			  <?php wp_nav_menu( array( 'theme_location' => 'footer', 'menu_class' => '') ); ?>
            </div>
            <div class="rightseparator"></div>
          </div>
          <div class="col-md-3 col-sm-6 mrgformobile">
            <div class="clearfix contactinfo">
				<h3>Contact Address</h3>
				<div class="col-lg-1 col-xs-1 col-md-1 col-sm-1 nomargin">
					<span class="addricon"></span>
				</div>
				<div class="col-lg-11 col-xs-11 col-md-11 col-sm-11 mrgformobile contantaddress">
					<p>AFFLUENCER FINANCIAL<br />
					3415 S Sepulveda Blvd Suite<br />1100, Los Angeles, CA 90034</p>
				</div>
				<div class="col-lg-1 col-xs-1 col-md-1 col-sm-1 nomargin">
					<span class="mobileicon"></span>
				</div>
				<div class="col-lg-11 col-xs-11 col-md-11 col-sm-11 mrgformobile">
					<p>(310) 730-1330</p>
				</div>
				<div class="col-lg-1 col-xs-1 col-md-1 col-sm-1 nomargin">
					<span class="emailicon"></span>
				</div>
				<div class="col-lg-11 col-xs-11 col-md-11 col-sm-11 mrgformobile">
					<p>info@affluencer.com</p>
				</div>
				<div class="col-lg-1 col-xs-1 col-md-1 col-sm-1 nomargin">
					<span class="clockicon"></span>
				</div>
				<div class="col-lg-11 col-xs-11 col-md-11 col-sm-11 mrgformobile">
					<p>Today 9:00 am - 5:00 pm</p>
				</div>
            </div>
            <div class="rightseparator"></div>
          </div>
			<div class="col-md-7 col-sm-12 nomargin">
				<div class="col-md-6 col-sm-12 mrgformobile">
					<div class="clearfix mapdet">
						<h3>LOCATION MAP</h3>
						<a href="https://www.google.co.in/maps/place/AFFLUENCER+FINANCIAL+ADVISORS/@34.0204416,-118.4263378,17z/data=!3m1!4b1!4m5!3m4!1s0x80c2ba4cf6fd1e7b:0x4344f690b9b2a204!8m2!3d34.0204416!4d-118.4241491?hl=en" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/map.jpg" class="img-responsive" /></a>
					</div>
					<div class="rightseparator"></div>
				</div>
				<div class="col-md-6 col-sm-12 mrglast">
					<div class="clearfix centerfootermap"> <img src="<?php echo get_template_directory_uri(); ?>/images/big-treeimage.png" />
					  <p>Affluencer financial is a fee only financial planning firm headquartered in Los Angeles, California. We do not make investment decisions on behalf of clients; rather we provide comprehensive advice and solutions without encouraging you to buy products. In fact, we do not manage securities nor are we affiliated with any investment firm that provides us management fees based on the purchase or trade of stocks, bonds, or mutual funds. We simply provide clients with unbiased, independent, objective advice on their personal financial goals.</p>
					</div>
				</div>
			</div>
        </div>
      </div>
    </div>
  </div>
  <div class="copyright">
    <div class="container">
      <div class="row">
        <div class="col-md-7 col-sm-6">
          <p class="clearfix">COPYRIGHT &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>,  ALL RIGHTS RESERVED</p>
        </div>
        <div class="col-md-2 col-sm-3">
			<?php wp_nav_menu( array( 'theme_location' => 'secondary', 'menu_class' => 'clearfix faqblcok') ); ?>
        </div>
        <div class="col-md-3 col-sm-3 ">
          <ul class="socialicon clearfix">
            <li><a href=""><img src="<?php echo get_template_directory_uri(); ?>/images/fb.png" /></a> </li>
            <li><a href=""><img src="<?php echo get_template_directory_uri(); ?>/images/tw.png" /></a> </li>
            <li><a href=""><img src="<?php echo get_template_directory_uri(); ?>/images/gp.png" /></a> </li>
            <li><a href=""><img src="<?php echo get_template_directory_uri(); ?>/images/subscribe.png" /></a> </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer>
<?php wp_footer() ?>
<script>
var $ = jQuery.noConflict();
</script>
<script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.stellar.min.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/modernizr.custom.71422.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/pushy.min.js" type="text/javascript"></script>
<script>
if (screen && screen.width > 640) {
  document.write('<script src="<?php echo get_template_directory_uri(); ?>\/js/uikit.min.js"><\/script>');
}
</script>
<script src="<?php echo get_template_directory_uri(); ?>/js/scrollspy.min.js"></script>
<!-- Added By Dharmesh Start -->
<script src="<?php echo get_template_directory_uri(); ?>/js/owl.carousel.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.mCustomScrollbar.concat.min.js"></script>
<!-- Added By Dharmesh End -->
<?php if( is_front_page()){ ?>
<script>
	jQuery( document ).ready(function() {
    //Function to animate slider captions
  	function doAnimations( elems ) {
  		//Cache the animationend event in a variable
  		var animEndEv = 'webkitAnimationEnd animationend';

  		elems.each(function () {
  			var $this = $(this),
  				$animationType = $this.data('animation');
  			$this.addClass($animationType).one(animEndEv, function () {
  				$this.removeClass($animationType);
  			});
  		});
  	}

  	//Variables on page load
  	var $myCarousel = $('#carousel-example-generic,#carousel-example-generic-1380'),
  		$firstAnimatingElems = $myCarousel.find('.item:first').find("[data-animation ^= 'animated']");

  	//Initialize carousel
  	$myCarousel.carousel({
  	interval: 7000
	});

  	//Animate captions in first slide on page load
  	doAnimations($firstAnimatingElems);

  	//Pause carousel
  	$myCarousel.carousel('pause');


  	//Other slides to be animated on carousel slide event
  	$myCarousel.on('slide.bs.carousel', function (e) {
  		var $animatingElems = $(e.relatedTarget).find("[data-animation ^= 'animated']");
  		doAnimations($animatingElems);
  	});
	});
</script>
<?php } ?>
		<script>
			$(document).ready(function() {
			    $( '.container.menu li' ).hover(
			        function(){
			            $(this).children('ul').slideDown(300);
			        },
			        function(){
			            $(this).children('ul').slideUp(300);
			        }
			    );
			}); // end ready
		</script>
	</body>
</html>
