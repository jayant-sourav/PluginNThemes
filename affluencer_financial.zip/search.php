<?php get_header() ?>

<?php get_template_part( 'content-search' ); ?>

<?php get_footer() ?>
