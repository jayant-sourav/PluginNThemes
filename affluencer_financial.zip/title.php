<?php
      if( is_singular() && !is_front_page() ){
          $width = 390;
          if( '85' == get_the_ID() ){
              $width = 849;
          }
          $asso_pos = strpos(basename( get_page_template() ), 'page-associates');
          if( $asso_pos !== false ){
              $width = 270;
          }
					if( 'page-subscription.php' == basename( get_page_template() ) ){
						$width = 932;
					}
          ?>
                  <?php
                  if( $asso_pos !== false ){
                      echo "ASSOCIATES";
                  }else{
                      echo get_the_title();
                  }
                  ?>
          <?php
      }elseif(is_front_page() && !is_home()){
          ?>
          UNLIMITED ADVICE FOR A FLAT FEE
          <?php
      }elseif(!is_front_page() && is_home() && is_singular( 'post' )){
          ?>
          Blog
          <?php
      }elseif(is_front_page() && is_home()){
          ?>
          UNLIMITED <div class="rotate">ADVICE,INCREDIBLY,ESPECIALLY,EXTREMELY,INCREDIBLY</div> FOR A FLAT FEE
          <?php
      }elseif(is_404()){
			?>
					<?php _e( 'Oops! Page Not Found', 'xylus' );?>
			<?php
			}
			elseif(is_archive()){
					?>
							<?php
							if(is_author()):
									printf( __( 'All posts by %s', 'xylus' ), get_the_author() );

							elseif(is_category()):
									printf( __( 'Category Archives: %s', 'xylus' ), single_cat_title( '', false ) );

							elseif(is_tag()):
									printf( __( 'Tag Archives: %s', 'xylus' ), single_tag_title( '', false ) );

	elseif( is_day() ) :
									printf( __( 'Daily Archives: %s', 'xylus' ), get_the_date() );

							elseif ( is_month() ) :
									printf( __( 'Monthly Archives: %s', 'xylus' ), get_the_date( _x( 'F Y', 'monthly archives date format', 'xylus' ) ) );

							elseif ( is_year() ) :
									printf( __( 'Yearly Archives: %s', 'xylus' ), get_the_date( _x( 'Y', 'yearly archives date format', 'xylus' ) ) );

							else :
									_e( 'Archives', 'xylus' );

							endif;
							?>
					<?php

			}
			elseif( is_search()){ ?>
					<?php _e( 'Search Results for: ', 'xylus' ); echo esc_html( $GET['s'] )?>
			<?php
			}
      ?>