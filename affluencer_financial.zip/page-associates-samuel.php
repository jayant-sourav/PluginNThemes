<?php
/*
Template Name: Associates - Samuel F. Rad
*/
get_header();
the_post();

$associate_header_image  = ( get_field('associate_header_image'))?get_field('associate_header_image'):get_stylesheet_directory_uri()."images/blanca-estela-banner.jpg";
$associate_video_url  = ( get_field('associate_video_url'))?get_field('associate_video_url'):'';
if( $associate_video_url != ""){
	if( false !== strpos( $associate_video_url, 'youtube.com' ) ){
		$video_code	= str_replace( array( 'https://youtube.com/watch?v=', 'https://www.youtube.com/watch?v=', 'http://youtube.com/watch?v=', 'http://www.youtube.com/watch?v=' ), '', $associate_video_url);
		if( $video_code !=  "" ){
			?>
					<iframe class="headvideo samuelpage" width="100%" src="https://www.youtube.com/embed/<?php echo $video_code; ?>" frameborder="0" allowfullscreen></iframe>
			<?php
		}
	}elseif(false !== strpos( $associate_video_url, 'vimeo.com' ) ){
		$video_code	= str_replace(array('https://vimeo.com/','https://www.vimeo.com/','http://vimeo.com/','http://www.vimeo.com/'),'',$associate_video_url);
		if( $video_code !=  "" ){
			?>
					<iframe class="headvideo samuelpage" src="https://player.vimeo.com/video/<?php echo $video_code; ?>?title=0&byline=0&portrait=0" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
			<?php
		}
	}
}else{
	if( $associate_header_image != ""){
		?>
		<div class="associates-Banner">
			<img src="<?php echo esc_url($associate_header_image); ?>" alt="" />
		</div>
		<?php
	}
}
?>

<?php
	if( have_rows('associates_sections') ){
		echo '<div class="container educationLst"><div class="row">';
		$i = 0;
		while ( have_rows('associates_sections') ) : the_row();

			$asso_sec_image = (get_sub_field('asso_sec_image'))?get_sub_field('asso_sec_image'): "";
			$asso_sec_title = (get_sub_field('asso_sec_title'))?get_sub_field('asso_sec_title'): "";
			$asso_sec_content = (get_sub_field('asso_sec_content'))?get_sub_field('asso_sec_content'): "";
			$asec_button_title = (get_sub_field('asec_button_title'))?get_sub_field('asec_button_title'): "CLICK HERE TO SEE LIVE CLASSES";
			$asec_button_link = (get_sub_field('asec_button_link'))?get_sub_field('asec_button_link'): "";

			if( $asso_sec_title !=  "" ){
				?>

				<div class="col-sm-4">
					<div class="education-bg <?php if( $i == 1){ echo 'licenses-bg'; } if( $i == 2){ echo 'engagements-bg'; }?>">
						<div class="educationImg">
							<img src="<?php echo esc_url($asso_sec_image); ?>" alt="<?php echo $asso_sec_title; ?>" />
						</div>
						<div class="educationContnt">
							<h3><?php echo $asso_sec_title; ?></h3>
							<?php echo $asso_sec_content; ?>
							<?php
							if( $asec_button_link != "" ){
								echo '<span class="clickHere-btn"><a href="'.esc_url($asec_button_link).'">'.$asec_button_title.'</a></span>';
							}
							?>
						</div>
					</div>
				</div>
				<?php
			}
			$i++;
		endwhile;
		echo '</div></div>';
	}
?>

<?php
// Render Associate Testimonials
if( function_exists('render_associate_client_testimonials') ){
	render_associate_client_testimonials();
}
?>

<?php
// Render Call Now
if( function_exists('render_call_now_sections') ){
	render_call_now_sections();
}
?>

<?php
// Render Footer Video Testimonials
if( function_exists('render_video_testimonials_footer_section') ){
	render_video_testimonials_footer_section();
}
?>



</div>
</div>

<?php //get_sidebar() ?>
<?php get_footer() ?>
