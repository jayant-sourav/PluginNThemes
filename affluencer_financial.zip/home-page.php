<?php
/*
Template Name: Home Page
*/
get_header();
the_post();
?>
<div id="banner-video" class="slider-all">
	<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
	  <!-- Indicators -->
	  <ol class="carousel-indicators">
		<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
		<li data-target="#carousel-example-generic" data-slide-to="1"></li>
		<li data-target="#carousel-example-generic" data-slide-to="2"></li>
		<li data-target="#carousel-example-generic" data-slide-to="3"></li>
		<li data-target="#carousel-example-generic" data-slide-to="4"></li>
	  </ol>
	  <!-- Wrapper for slides -->
	  <div class="carousel-inner" role="listbox">
			<?php
				$i=0;
			  if( have_rows('slider') ):
			    while( have_rows('slider') ): the_row();
					$i++;

			  ?>
			  <div class="item<?php if($i == 1) { echo ' active';} ?>">
<img src="<?php echo get_sub_field('image'); ?>" alt="<?php echo get_sub_field('title'); ?>" class="new-slider"/>
			<div class="carousel-caption">
			  <h3 data-animation="animated <?php echo get_sub_field('animation_class'); ?>"><?php echo get_sub_field('title'); ?></h3>
			  <h2 data-animation="animated <?php echo get_sub_field('animation_class'); ?>"><?php echo get_sub_field('detail'); ?></h2>
			  <div>
			    <i data-animation="animated <?php echo get_sub_field('animation_class'); ?>"><?php echo get_sub_field('description'); ?></i>
			  </div>
			  <div>

			    <a href="<?php echo get_sub_field('button_link'); ?>" class="slider-button" data-animation="animated <?php echo get_sub_field('animation_class'); ?>"><?php echo get_sub_field('button_name'); ?></a>
			  </div>
			</div>
			</div>
			<?php
			endwhile;
			endif;
			?>
	  </div>

	  <!-- Controls -->
	  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
		<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
		<span class="sr-only">Previous</span>
	  </a>
	  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
		<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
		<span class="sr-only">Next</span>
	  </a>
	</div>
</div>
<div id="banner-video" class="slider-1380">
	<div id="carousel-example-generic-1380" class="carousel slide" data-ride="carousel">
	  <!-- Indicators -->
	  <ol class="carousel-indicators">
		<li data-target="#carousel-example-generic-1380" data-slide-to="0" class="active"></li>
		<li data-target="#carousel-example-generic-1380" data-slide-to="1"></li>
		<li data-target="#carousel-example-generic-1380" data-slide-to="2"></li>
		<li data-target="#carousel-example-generic-1380" data-slide-to="3"></li>
		<li data-target="#carousel-example-generic-1380" data-slide-to="4"></li>
	  </ol>
	  <!-- Wrapper for slides -->
		<div class="carousel-inner" role="listbox">
			<?php
				$i=0;
			  if( have_rows('slider_1380') ):
			    while( have_rows('slider_1380') ): the_row();
					$i++;

			  ?>
			  <div class="item<?php if($i == 1) { echo ' active';} ?>">
<img src="<?php echo get_sub_field('image'); ?>" alt="<?php echo get_sub_field('title'); ?>" class="new-slider"/>


			   <!-- <img src="<?php echo get_template_directory_uri(); ?>/images/s1.jpg" alt="" class="laptop-slider">-->
			<div class="carousel-caption">
			  <h3 data-animation="animated <?php echo get_sub_field('animation_class'); ?>"><?php echo get_sub_field('title'); ?></h3>
			  <h2 data-animation="animated <?php echo get_sub_field('animation_class'); ?>"><?php echo get_sub_field('detail'); ?></h2>
			  <div>
			    <i data-animation="animated <?php echo get_sub_field('animation_class'); ?>"><?php echo get_sub_field('description'); ?></i>
			  </div>
			  <div>

			    <a href="<?php echo get_sub_field('button_link'); ?>" class="slider-button" data-animation="animated <?php echo get_sub_field('animation_class'); ?>"><?php echo get_sub_field('button_name'); ?></a>
			  </div>
			</div>
			</div>
			<?php
			endwhile;
			endif;
			?>
	  </div>

	  <!-- Controls -->
	  <a class="left carousel-control" href="#carousel-example-generic-1380" role="button" data-slide="prev">
		<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
		<span class="sr-only">Previous</span>
	  </a>
	  <a class="right carousel-control" href="#carousel-example-generic-1380" role="button" data-slide="next">
		<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
		<span class="sr-only">Next</span>
	  </a>
	</div>
</div>
<div class="whitebg text-center padTB30">
  <div class="container">
    <div class="sectionheadng">
      <h2><?php echo get_field('what_we_do_title'); ?></h2>
    </div>
	 <div class="paragraph">
	 <p><?php echo get_field('what_we_do_discription'); ?></p>
	 </div>
  </div>
</div>
<div class="whitebg text-center padT30B10">
<div class="container">
  <div class="row text-center">
	<?php
		// check if the repeater field has rows of data
		if( have_rows('services') ):
			$detalty= 300;
			$i		= 1;

			// loop through the rows of data
			while ( have_rows('services') ) : the_row();

				// vars
				$image		= get_sub_field('image');
				$title		= get_sub_field('title');
				$description= get_sub_field('description');
			?>
				<div class="col-md-3 col-sm-6 col-xs-6" data-uk-scrollspy="{cls:'uk-animation-slide-bottom', repeat: true, delay:<?php echo $detalty*$i; ?>}">
				  <div class="clearfix financialinfo">
					<h2 class="text-center"><?php echo $title; ?></h2>
					<div class="pad5 findet">
					  <div class="img mrgTB5">
						<?php
							if($image == '')
							{
								echo '<img src="http://placehold.it/300x185/ea9913/ffffff?text=No Image" alt="No Image" />';
							}
							else
							{
								echo '<img src="'.$image.'" alt="'.$title.'" />';
							}
						?>
						</div>
					  <p><?php echo $description; ?></p>
					</div>
				  </div>
				</div>
			<?php
				$i++;
			endwhile;
		endif;
	?>
	</div>
  </div>
</div>

<div class="video">

 <?php echo do_shortcode("[huge_it_video_player id='2']"); ?>

</div>
<div class="whitebg text-center padTB30 head">
  <div class="container-fluid">
    <div class="yellohead">
      <h2><?php echo get_field('who_we_are_title'); ?></h2>
	  <div class="paragrap">
	   <p><?php echo get_field('who_we_are_discription'); ?></p>
	  </div>
    </div>
    <div class="whywehereblock" data-uk-scrollspy="{cls:'uk-animation-slide-bottom', repeat: true, delay:300}">
    </div>
  </div>
</div>
<div class="clearfix bannerbgprcharge text-center">
	<div class="container">
    <div class="row text-center finaplanoutermain">
		<?php
			// check if the repeater field has rows of data
			if( have_rows('certificates') ):
				// loop through the rows of data
				$i	= 0;
				while ( have_rows('certificates') ) : the_row();

					// vars
					$image		= get_sub_field('image');
					$title		= get_sub_field('title');
					$description= get_sub_field('description');
					$max		= 1200;
					$delay		= $max-((($i*2)-1)*300);
					$i++;
				?>
					<div class="col-md-4 col-sm-6 col-xs-12  finaplanouter" data-uk-scrollspy="{cls:'uk-animation-slide-left', repeat: true, delay:<?php echo $delay; ?>}">
						<div class="clearfix finaplannerblock">
						 <h2><?php echo $title; ?></h2>
						  <div class="shadow">
                            <div class="img">
								<?php
									if($image == '')
									{
										echo '<img src="http://placehold.it/125x125/ea9913/ffffff?text=No Logo" alt="No Logo" />';
									}
									else
									{
										echo '<img src="'.$image.'" alt="'.$title.'" />';
									}
								?>
							</div>
						  <p><?php echo $description; ?></p>

								</div>

						</div>

					  </div>

				<?php

				endwhile;
			endif;
		?>
    </div>
  </div>
  <div class="container">
    <div class="sectionheadng">
      <h2><?php echo get_field('charge_title'); ?></h2>
    </div>
    <div class="projecttags padTB10" data-uk-scrollspy="{cls:'uk-animation-slide-bottom', repeat: true, delay:300}">
		<p><?php echo get_field('charge_discription'); ?></p>
    </div>
    <div class="projecthourblock clearfix text-center">
      <div class="col-md-4 col-sm-4 col-xs-12">
        <div class="projectblock" data-uk-scrollspy="{cls:'uk-animation-slide-left', repeat: true, delay:300}">




					<a href=""><img class="uk-animation-fade uk-animation-hover uk-animation-20" src="<?php echo get_template_directory_uri(); ?>/images/project-1.jpg" /></a>
          <h2>PROJECT</h2>
          <p><?php echo get_field('project_description'); ?></p>
        </div>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-12">
        <div class="projectblock projmonth" data-uk-scrollspy="{cls:'uk-animation-slide-bottom', repeat: true, delay:300}"> <a href=""><img class="uk-animation-fade uk-animation-hover uk-animation-20" src="<?php echo get_template_directory_uri(); ?>/images/monthly.png" /></a>
          <h2>Monthly</h2>
          <p><?php echo get_field('monthly_charge'); ?></p>
        </div>
      </div>
      <div class="projcenterimg"></div>
      <div class="col-md-4 col-sm-4 col-xs-12">
        <div class="projectblock projhours" data-uk-scrollspy="{cls:'uk-animation-slide-right', repeat: true, delay:300}"> <a href=""><img class="uk-animation-fade uk-animation-hover uk-animation-20" src="<?php echo get_template_directory_uri(); ?>/images/hourly.png" /></a>
          <h2>Hourly</h2>
          <p><?php echo get_field('hourly_charge'); ?></p>
        </div>
      </div>
      <div class="half-circle"></div>
      <div class="right-half-circle" data-uk-scrollspy="{cls:'uk-animation-slide-bottom', repeat: true, delay:300}"></div>
    </div>
  </div>
</div>
<div class="clearfix clientsreview text-center">
  <div class="sectionheadng mrgTB20">  <!--data-uk-scrollspy="{cls:'uk-animation-slide-bottom', repeat: true, delay:300}"-->

    <h2><span>WHAT OUR </span> CLIENTS SAY</h2>

  </div>

	<div class="clientreviewimg">  <!--data-uk-scrollspy="{cls:'uk-animation-slide-bottom', repeat: true, delay:300}"-->
            <div class="slider-wrap">
           <div class="slider">
            <ul>
		<?php

			// check if the repeater field has rows of data

			if( have_rows('clients_videos') ):


				// loop through the rows of data
				while ( have_rows('clients_videos') ) : the_row();

					// vars
					$video_url	= get_sub_field('video_url');
					$video_code	= str_replace(array('https://vimeo.com/','https://www.vimeo.com/','http://vimeo.com/','http://www.vimeo.com/'),'',$video_url);

					if($video_code != '')
					{
				?>
                    <li>
					<div class="col-xs-12 col-sm-12 mobilewidth">
						<iframe style="width:100%;" src="https://player.vimeo.com/video/<?php echo $video_code; ?>?title=0&byline=0&portrait=0" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
					</div>
                    </li>
				<?php
					}
				endwhile;
			endif;
		?>
     </ul>
     </div>
     </div>
	<div class="text-center padTB10 nextprevicons"> <span class="nexticon"></span> <span class="previcon"></span></div>
	<script src="http://code.jquery.com/jquery-latest.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.lbslider.js"></script>
	<script>
		var width = (window.innerWidth > 0) ? window.innerWidth : screen.width;

		var slide = 3;

		//if ($(window).width() < 600) {
		if (width < 600) {
			var slide = 1;
		}
		//else if($(window).width() > 600 && $(window).width() <= 768 ) {
		else if(width > 600 && width <= 768 ) {
			var slide = 2;
		}

		$('.slider').lbSlider({
			leftBtn: '.nexticon',
			rightBtn: '.previcon',
			visible: slide,
			autoPlay: false,
			infinite: true,
			autoPlayDelay: 5,
			responsive: [
			{
			  breakpoint: 480,
			  settings: {
			  visible:1,
			  infinite: true
			  }
			}
		  ]
		});
	</script>
	</div>

</div>

<div class="graybg">
  <div class="container row reviewclasssec">
    <div class="col-md-6 col-sm-12 revi">
      <div class="reviewsec row">
        <div class="sectionheadng padTB30">
          <h2><span> YELP </span> REVIEWS</h2>
        </div>
				<?php dynamic_sidebar( 'home_footer_1' ); ?>
      </div>
    </div>
    <div class="blocksepaline"></div>
    <div class="col-md-6 col-sm-12 revi">
      <div class="upcomingclasses row">
        <div class="sectionheadng padTB30">
          <h2><span> UPCOMING </span> COLLEGE CLASSES</h2>
        </div>
				<?php
      $events = eo_get_events(array(
              'numberposts'=>4,
              'event_start_after'=>'today',
              'showpastevents'=>true,//Will be deprecated, but set it to true to play it safe.
         ));

       if($events):
          foreach ($events as $event):
						//Check if all day, set format accordingly
						$format = ( eo_is_all_day($event->ID) ? get_option('date_format') : get_option('date_format').' '.get_option('time_format') );

						// vars
						//$logo		= get_sub_field('logo');
						$title		= get_the_title($event->ID);
						//$description= get_sub_field('description');
						$venue_id = eo_get_venue($event->ID);
						$location	= eo_get_venue_name($venue_id);
						$date		= eo_get_the_start( $format, $event->ID, $event->occurrence_id );
						$url		= get_permalink($event->ID);
						?>
						<div class="reviewbl clearfix">
							<!--<div class="img pull-left">-->
								<?php
									/* if($logo == '')
									{
										echo '<img src="http://placehold.it/75x75/ea9913/ffffff?text=No Logo" alt="No Logo" />';
									}
									else
									{
										echo '<img src="'.$logo.'" alt="'.$title.'" class="im-2"/>';
									} */
								?>
							<!--</div>-->
						  <div class="clearfix classdet">
							<h4><?php echo $title; ?></h4>
							<p><?php //echo $description; ?> </p>
							<div class="clearfix mrgB3">
							  <p class="datetext"><span class="mapicon"></span><?php echo $location; ?></p>
							  <p class="datetext"><span class="calicon"></span><?php echo mysql2date('n/j/Y', $date); ?></p>
							</div>
							<a class="readmore" href="<?php echo $url; ?>" target="_blank">Register For This Class</a> </div>
						</div>
						<?php
          endforeach;
       endif;
      ?>
		<?php
			// check if the repeater field has rows of data
			/* if( have_rows('upcoming_college_classes') ):
				// loop through the rows of data
				while ( have_rows('upcoming_college_classes') ) : the_row();
					// vars
					$logo		= get_sub_field('logo');
					$title		= get_sub_field('title');
					$description= get_sub_field('description');
					$location	= get_sub_field('location');
					$date		= get_sub_field('date');
					$url		= get_sub_field('url');
				?>
					<div class="reviewbl clearfix">
						<div class="img pull-left">
							<?php
								if($logo == '')
								{
									echo '<img src="http://placehold.it/75x75/ea9913/ffffff?text=No Logo" alt="No Logo" />';
								}
								else
								{
									echo '<img src="'.$logo.'" alt="'.$title.'" class="im-2"/>';
								}
							?>
						</div>
					  <div class="clearfix classdet">
						<h4><?php echo $title; ?></h4>
						<p><?php echo $description; ?> </p>
						<div class="clearfix mrgB3">
						  <p class="datetext pull-left"><span class="mapicon"></span><?php echo $location; ?></p>
						  <p class="datetext pull-left"><span class="calicon"></span><?php echo mysql2date('j/n/Y', $date); ?></p>
						</div>
						<a class="readmore" href="<?php echo $url; ?>" target="_blank">Register For This Class</a> </div>
					</div>
				<?php
				endwhile;
			endif; */
		?>
      </div>
    </div>
  </div>
</div>
<?php //get_sidebar() ?>
<style>.graybg.whitebg .footertoppart{background-color:#eee !important;}</style>
<?php get_footer();
