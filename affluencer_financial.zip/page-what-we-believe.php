<?php
/*
Template Name: What we Believe Page
*/ 
get_header();
the_post();
?>
<div class="what-we-believe">
	<div class="container">
		<?php
			$believe_sub_title = (get_field('believe_sub_title'))?get_field('believe_sub_title'):"WE BELIEVE EVERY PROBLEM HAS MORE THAN ONE SOLUTION.";
		?>
		<h2><?php echo $believe_sub_title; ?></h2>
		<?php
		if( have_rows('believe_sections') ){
			echo '<div class="weBelieve-contnt">
					 <div class="row">';

			while ( have_rows('believe_sections') ) : the_row();

				$believe_image	= esc_url(get_sub_field('believe_image'));
				$believe_title	= get_sub_field('believe_title');
				$believe_content = get_sub_field('believe_content');
				if( $believe_title !=  "" ){
					?>
					<div class="col-sm-4">
						<div class="believeIcon"><img src="<?php echo $believe_image; ?>" alt="" /></div>
						<h3><?php echo $believe_title; ?></h3>
						<div id="content-1" class="content">
							<p><?php echo $believe_content?></p>
						</div>
					</div>
					<?php
				}

			endwhile;
			echo '</div></div>';
		}
		?>
	</div>
</div>

<?php
	$display_call_cta = (get_field('display_call_cta', get_the_ID()))?get_field('display_call_cta', get_the_ID()):get_field('display_call_cta', 'option');
if( $display_call_cta == '1'){

	$call_title = $call_subtitle = $call_mess_button_text = $call_tele_button_text = "";
	$call_mess_button_link = $call_tele_button_link = "";

	$call_title = (get_field('call_title', get_the_ID()))?get_field('call_title', get_the_ID()):get_field('call_title', 'option');
	$call_subtitle = (get_field('call_sub_title', get_the_ID()))?get_field('call_sub_title', get_the_ID()):get_field('call_sub_title', 'option');
	$call_tele_button_text = (get_field('call_tele_button_text', get_the_ID()))?get_field('call_tele_button_text', get_the_ID()):get_field('call_tele_button_text', 'option');
	$call_tele_button_link = (get_field('call_tele_button_link', get_the_ID()))?get_field('call_tele_button_link', get_the_ID()):get_field('call_tele_button_link', 'option');
	$call_mess_button_text = (get_field('call_mess_button_text', get_the_ID()))?get_field('call_mess_button_text', get_the_ID()):get_field('call_mess_button_text', 'option');
	$call_mess_button_link = (get_field('call_mess_button_link', get_the_ID()))?get_field('call_mess_button_link', get_the_ID()):get_field('call_mess_button_link', 'option');

	?>
	<div class="callNow-area">
		<div class="callNow-Box">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mobile-img"><img src="<?php echo get_template_directory_uri(); ?>/images/mobile-img.png" alt="" /></div>
					</div>

					<div class="col-md-8">
						<div class="callNow-Text">
							<h2><?php echo $call_title; ?></h2>
							<span><?php echo $call_subtitle; ?></span>
							<div class="Message-Callus">
								<a href="<?php echo $call_tele_button_link; ?>"><span class="call-icon"></span><?php echo $call_tele_button_text; ?></a>
								<a href="<?php echo $call_mess_button_link; ?>"><span class="message-icon"></span><?php echo $call_mess_button_text; ?></a>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
	<?php
}
?>
</div>
<?php
$client_title = (get_field('client_title', get_the_ID()))?get_field('client_title', get_the_ID()):get_field('client_title', 'option');
if ($client_title == ""){
	$client_title = "<span>WHAT OUR</span> CLIENTS SAY?";
}
?>
<div class="whitebg text-center padTB30 clientSaybg">
	<div class="container">
		<div class="clientSayTitle">
			<h2><?php echo $client_title; ?></h2>
		</div>
		<div class="clientSay">
			<?php
			if( have_rows('clients_test_videos', get_the_ID()) ){
				echo '<div class="owl-carousel1">';
				while ( have_rows('clients_test_videos') ) : the_row();
					$video_url	= get_sub_field('test_video_url');
					$video_code	= str_replace(array('https://vimeo.com/','https://www.vimeo.com/','http://vimeo.com/','http://www.vimeo.com/'),'',$video_url);
					if( $video_code !=  "" ){
						?>
						<div class="item">
							<div class="clientVideo">
								<iframe style="width:100%;" src="https://player.vimeo.com/video/<?php echo $video_code; ?>?title=0&byline=0&portrait=0" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
							</div>
						</div>
						<?php
					}
				endwhile;
				echo '</div>';
			}else{
				if( have_rows('clients_test_videos', 'options' ) ){
					echo '<div class="owl-carousel1">';
					while ( have_rows('clients_test_videos', 'options') ) : the_row();
						$video_url	= get_sub_field('test_video_url', 'options');
						$video_code	= str_replace(array('https://vimeo.com/','https://www.vimeo.com/','http://vimeo.com/','http://www.vimeo.com/'),'',$video_url);
						if( $video_code !=  "" ){
							?>
							<div class="item">
								<div class="clientVideo">
									<iframe style="width:100%;" src="https://player.vimeo.com/video/<?php echo $video_code; ?>?title=0&byline=0&portrait=0" height="290" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
								</div>
							</div>
							<?php
						}
					endwhile;
					echo '</div>';
				}
			}


			?>

			</div>

		</div>

	</div>
</div>

	<script>
		jQuery(document).ready( function () {
			jQuery('.owl-carousel1').owlCarousel({
				loop:true,
				margin:10,
				nav:true,
				responsive:{
					0:{
						items:1
					},
					600:{
						items:2
					},
					800:{
						items:3
					},
					1000:{
						items:3
					}
				}
			});

			(function($){
				$(window).on("load",function(){
					$("#content-1,#content-2,#content-3,#content-4,#content-5").mCustomScrollbar({
						theme:"minimal"
					});
				});
			})(jQuery);
		});
	</script>

<?php //get_sidebar() ?>
<style>.graybg.whitebg .footertoppart{background-color:#F9F9F9 !important;}</style>
<?php get_footer() ?>