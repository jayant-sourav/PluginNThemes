<?php
/*
Template Name: Estate Planning
*/
get_header();
the_post();
?>

<?php
	if( have_rows('estate_planning_section') ){
		echo '<div class="estatePlann">';
		$i = 0;
		while ( have_rows('estate_planning_section') ) : the_row();

			$estate_plan_sec_image = (get_sub_field('estate_plan_sec_image'))?get_sub_field('estate_plan_sec_image'): "";
			$estate_plan_sec_title = (get_sub_field('estate_plan_sec_title'))?get_sub_field('estate_plan_sec_title'): "";
			$estate_plan_sec_content = (get_sub_field('estate_plan_sec_content'))?get_sub_field('estate_plan_sec_content'): "";

			if( $estate_plan_sec_title !=  "" ){
				if( $i % 2 == 0 ){
						$even = true;
				}else{
					  $even = false;
				}
				?>
				<div class="estate1 <?php if( !$even ){ echo 'estate2'; } ?>">
					<?php
					if( $even ){
						?>
						<div class="estateLeft" style="background: url('<?php echo $estate_plan_sec_image; ?>') no-repeat center center; background-size: cover;">
						</div>
						<?php
					}
					?>
						<div class="<?php if( $even ){ echo 'estateRight'; }else{ echo 'estateLeft'; } ?>">
								<div class="estateContnt <?php if( !$even ){ echo 'planLeft'; } ?>">
									<h2><?php echo $estate_plan_sec_title; ?></h2>
									<?php echo $estate_plan_sec_content; ?>
								</div>
				      </div>
							<?php
							if( !$even ){
								?>
								<div class="estateRight" style="background: url('<?php echo $estate_plan_sec_image; ?>') no-repeat center center; background-size: cover;">
									
								</div>
								<?php
							}
							?>
				</div>
				<?php
			}
			$i++;
		endwhile;
		echo '</div>';
	}
?>

</div>

<?php
$estate_footer_sec_bg = (get_field('estate_footer_sec_bg'))?get_field('estate_footer_sec_bg'):"";
$estate_footer_sec_title = (get_field('estate_footer_sec_title'))?get_field('estate_footer_sec_title'):"";
$estate_footer_sec_button = (get_field('estate_footer_sec_button'))?get_field('estate_footer_sec_button'):"SET AN APPOINTMENT";
$estate_footer_sec_but_link = (get_field('estate_footer_sec_but_link'))?get_field('estate_footer_sec_but_link'):"#";
?>
<div class="made-easy-bg-img" style="<?php if($estate_footer_sec_bg !=""){ echo "background: url('".esc_url($estate_footer_sec_bg)."') no-repeat center center;background-size:cover;"; } ?>">
<div class="container">
	<h2><?php echo $estate_footer_sec_title; ?></h2>
    <div class="appointment-btn"><a href="<?php echo esc_url($estate_footer_sec_but_link); ?>"><?php echo $estate_footer_sec_button; ?></a></div>

		<?php
		if( have_rows('estate_footer_services') ){
			echo '<div class="made-easy"><ul>';
			$i = 0;
			while ( have_rows('estate_footer_services') ) : the_row();
			$esata_footer_ser_image = (get_sub_field('esata_footer_ser_image'))?get_sub_field('esata_footer_ser_image'):"";
			$esata_footer_ser_title = (get_sub_field('esata_footer_ser_title'))?get_sub_field('esata_footer_ser_title'):"";
			?>
			<li>
				<img src="<?php echo esc_url($esata_footer_ser_image); ?>" alt="<?php echo $esata_footer_ser_title; ?>" />
				<span><?php echo $esata_footer_ser_title; ?></span>
			</li>
			<?php
			endwhile;
			echo '</ul></div>';
		}
		?>

</div>
</div>
<style>
.whitebg .footertoppart, footer {
    background-color: transparent !important;
}
</style>


<?php //get_sidebar() ?>
<?php get_footer() ?>
