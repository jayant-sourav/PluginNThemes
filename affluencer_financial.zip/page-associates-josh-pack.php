<?php
/*
Template Name: Associates - John Pak
*/
get_header();
the_post();

$associate_header_image  = ( get_field('associate_header_image'))?get_field('associate_header_image'):get_stylesheet_directory_uri()."images/edmund-vincent-img.png";
$associate_name  = ( get_field('associate_name'))?get_field('associate_name'):'JOHN PAK';
$associate_position  = ( get_field('associate_position'))?get_field('associate_position'):'CERTIFIED FINANCIAL PLANNER';
$associate_video_url  = ( get_field('associate_video_url'))?get_field('associate_video_url'):'';
?>

<div class="johnpak-Banner">
	<?php
		if( have_rows('associates_sections') ){
			echo '<div class="johnpak-Banner-Right ">';
			?>
			<h2><?php echo $associate_name; ?><span><?php echo $associate_position; ?></span></h2>
			<?php
			$i = 0;
			while ( have_rows('associates_sections') ) : the_row();

				$asso_sec_image = (get_sub_field('asso_sec_image'))?get_sub_field('asso_sec_image'): "";
				$asso_sec_title = (get_sub_field('asso_sec_title'))?get_sub_field('asso_sec_title'): "";
				$asso_sec_content = (get_sub_field('asso_sec_content'))?get_sub_field('asso_sec_content'): "";
				$asec_button_title = (get_sub_field('asec_button_title'))?get_sub_field('asec_button_title'): "CLICK HERE TO SEE LIVE CLASSES";
				$asec_button_link = (get_sub_field('asec_button_link'))?get_sub_field('asec_button_link'): "";

				if( $asso_sec_title !=  "" ){
					?>
					<div class="bannerBox1 <?php if( $i == 1){ echo 'bannerBox2'; } if( $i == 2){ echo 'bannerBox3'; }?>">
						<span><img src="<?php echo esc_url($asso_sec_image); ?>" alt="<?php echo $asso_sec_title; ?>" /></span>
						<div class="bannerContnt">
							<h3><?php echo $asso_sec_title; ?></h3>
							<?php echo $asso_sec_content; ?>
							<?php
							if( $asec_button_link != "" ){
								echo '<div class="clickbtn"><a href="'.esc_url($asec_button_link).'">'.$asec_button_title.'</a></div>';
							}
							?>
						</div>

					</div>
					<?php
				}
				$i++;
			endwhile;
			echo '</div>';
		}
	?>
	<div class="johnpak-Banner-left">
		<div class="johnpak-banner-img">
			<?php
			if( $associate_video_url != ""){
				if( false !== strpos( $associate_video_url, 'youtube.com' ) ){
					$video_code	= str_replace( array( 'https://youtube.com/watch?v=', 'https://www.youtube.com/watch?v=', 'http://youtube.com/watch?v=', 'http://www.youtube.com/watch?v=' ), '', $associate_video_url);
					if( $video_code !=  "" ){
						?>
								<iframe class="headvideo" src="https://www.youtube.com/embed/<?php echo $video_code; ?>" frameborder="0" allowfullscreen></iframe>
						<?php
					}
				}elseif(false !== strpos( $associate_video_url, 'vimeo.com' ) ){
					$video_code	= str_replace(array('https://vimeo.com/','https://www.vimeo.com/','http://vimeo.com/','http://www.vimeo.com/'),'',$associate_video_url);
					if( $video_code !=  "" ){
						?>
								<iframe class="headvideo" src="https://player.vimeo.com/video/<?php echo $video_code; ?>?title=0&byline=0&portrait=0" height="600" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
						<?php
					}
				}

				?>
				<?php
			}else{
				if( $associate_header_image != ""){
					?>
					<img src="<?php echo esc_url($associate_header_image); ?>" alt="<?php echo $associate_name; ?>" />
					<?php
				}
			}

			?>
			<div class="John-Pak">
				<a href="#">
				<!-- <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/youtube-btn.png" alt="" /> -->
				<h1><?php echo $associate_name; ?></h1>
				<span><?php echo $associate_position; ?></span>
				</a>
			</div>
		</div>
	</div>
</div>
</div>

<?php
// Render Associate Testimonials
if( function_exists('render_associate_client_testimonials') ){
	render_associate_client_testimonials();
}
?>

<?php
// Render Call Now
if( function_exists('render_call_now_sections') ){
	render_call_now_sections();
}
?>

<?php
// Render Footer Video Testimonials
if( function_exists('render_video_testimonials_footer_section') ){
	render_video_testimonials_footer_section();
}
?>
</div>
</div>
<?php //get_sidebar() ?>
<?php get_footer() ?>