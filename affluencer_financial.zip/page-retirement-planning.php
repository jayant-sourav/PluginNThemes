<?php
/*
Template Name: Retirement Planning
*/
get_header();
the_post();
?>

<?php
	if( have_rows('retirement_plan_section') ){
		echo '<div class="retirement-planning">';
		$i = 0;
		while ( have_rows('retirement_plan_section') ) : the_row();

			$reti_plan_sec_image = (get_sub_field('reti_plan_sec_image'))?get_sub_field('reti_plan_sec_image'): "";
			$reti_plan_sec_title = (get_sub_field('reti_plan_sec_title'))?get_sub_field('reti_plan_sec_title'): "";
			$reti_plan_sec_content = (get_sub_field('reti_plan_sec_content'))?get_sub_field('reti_plan_sec_content'): "";

			if( $reti_plan_sec_title !=  "" ){
				if( $i % 2 == 0 ){ $even = true; }else{ $even = false; }
				?>
				<div class="<?php if( $even ){ echo 'retirementLeft'; } else { echo 'retirementRight'; }?>">
					<img src="<?php echo esc_url($reti_plan_sec_image); ?>" alt="<?php echo $reti_plan_sec_title; ?>" />
					<div class="<?php if( $even ){ echo 'retirementLeftContnt'; } else { echo 'retirementRightContnt'; }?>">
						<div class="<?php if( $even ){ echo 'planLeft'; } ?> planningcontnt">
						<h2><?php echo $reti_plan_sec_title; ?></h2>
						<?php echo $reti_plan_sec_content; ?>
						</div>
					</div>
				</div>
				<?php
			}
			$i++;
		endwhile;
		echo '</div>';
	}
?>

<?php
	if( have_rows('reti_middle_section') ){
		while ( have_rows('reti_middle_section') ) : the_row();
			$reti_medium_image = (get_sub_field('reti_medium_image'))?get_sub_field('reti_medium_image'): "";
			$reti_medium_title = (get_sub_field('reti_medium_title'))?get_sub_field('reti_medium_title'): "";
			$reti_medium_content = (get_sub_field('reti_medium_content'))?get_sub_field('reti_medium_content'): "";
			if( $reti_medium_title !=  "" ){
				?>
				<div class="container">
				<div class="retirement-Content">
					<div class="retirement-Content-Img"><img src="<?php echo esc_url($reti_medium_image); ?>" alt="<?php echo $reti_medium_title; ?>" /></div>
				    <h3><?php echo $reti_medium_title; ?></h3>
				    <p><?php echo $reti_medium_content; ?></p>
				</div>
				</div>
				<?php
			}
		endwhile;
	}
?>


</div>

<?php
$reti_footer_sec_bg = (get_field('reti_footer_sec_bg'))?get_field('reti_footer_sec_bg'):"";
$reti_footer_sec_title = (get_field('reti_footer_sec_title'))?get_field('reti_footer_sec_title'):"";
$reti_footer_sec_button = (get_field('reti_footer_sec_button'))?get_field('reti_footer_sec_button'):"SET AN APPOINTMENT";
$reti_footer_sec_but_link = (get_field('reti_footer_sec_but_link'))?get_field('reti_footer_sec_but_link'):"#";
?>
<div class="Retirement-appointment" style="<?php if($reti_footer_sec_bg !=""){ echo "background: url('".esc_url($reti_footer_sec_bg)."') no-repeat;background-size: cover;"; } ?>">
<div class="container">
	<h2><?php echo $reti_footer_sec_title; ?></h2>
    <div class="appointment-btn"><a href="<?php echo esc_url($reti_footer_sec_but_link); ?>"><?php echo $reti_footer_sec_button; ?></a></div>

		<?php
		if( have_rows('reti_footer_services') ){
			echo '<div class="worry-free"><ul>';
			$i = 0;
			while ( have_rows('reti_footer_services') ) : the_row();
			$reti_footer_ser_image = (get_sub_field('reti_footer_ser_image'))?get_sub_field('reti_footer_ser_image'):"";
			$reti_footer_ser_title 	 = (get_sub_field('reti_footer_ser_title'))?get_sub_field('reti_footer_ser_title'):"";
			?>
			<li>
				<img src="<?php echo esc_url($reti_footer_ser_image); ?>" alt="<?php echo $reti_footer_ser_title; ?>" />
				<span><?php echo $reti_footer_ser_title; ?></span>
			</li>
			<?php
			endwhile;
			echo '</ul></div>';
		}
		?>

</div>
</div>
<style>
.whitebg .footertoppart, footer {
    background-color: transparent !important;
}
</style>


<?php //get_sidebar() ?>
<?php get_footer() ?>
