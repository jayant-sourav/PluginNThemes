<?php get_header() ?>

<div class="blogPage">
	<div class="container blogArea">
		<div class="row">
			 <div class="col-sm-9">
					<?php if ( have_posts() ) : ?>
						<?php while ( have_posts() ) : the_post() ?>
						<div id="post-<?php the_ID() ?>" class="post blogContnt">
							<?php   if ( has_post_thumbnail() ) {
										$url = wp_get_attachment_url( get_post_thumbnail_id() );
										echo '<div class="BlogImg"><img src="'.esc_url( $url ).'" alt="" /></div>';
								} ?>
							<div class="blogtitle">
								<h3 class="post-title"><a href="<?php the_permalink() ?>" title="<?php the_title() ?>" rel="bookmark"><?php the_title() ?></a></h3>
								<p>By <span><?php the_author(); ?></span> on <?php the_time('F j, Y'); ?> in <span><?php the_category(', '); ?></span></p>
							</div>
							<div class="blogContent">
								<?php the_content(); ?>
							</div>
						</div><!-- .post -->
						<?php endwhile; ?>
					<?php endif; ?>
				</div>
				<?php get_sidebar() ?>
		</div>
	</div>
</div>
<style>
.whitebg .footertoppart, footer {
		background-color: transparent !important;
}
</style>
<?php get_footer() ?>
