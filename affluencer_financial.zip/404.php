<?php get_header() ?>

<div class="blogPage">
	<div class="container blogArea">
		<div class="row">
			 <div class="col-sm-9">
				 <div id="post-0" class="post error404">
		 			<div class="post-content">
						<br /><br />
		 				<h2 class="post-title" style="text-align: center;">Opps! Looks like you may have taken a wrong turn. Don’t worry it happens to the best of us. <a href="<?php echo get_site_url(); ?>">GO BACK TO THE HOME PAGE</a></h2>
		 			</div>
		 		</div><!-- .post -->

				</div>
				<?php get_sidebar() ?>
		</div>
	</div>
</div>
<style>
.whitebg .footertoppart, footer {
		background-color: transparent !important;
}
</style>

<?php get_footer() ?>
