<?php
/*
Template Name: Women Page
*/ 
get_header();
the_post();

$header_banner = (get_field('women_header_banner'))?get_field('women_header_banner'): get_stylesheet_directory_uri()."/images/women_page_Banner.png";

$women_video = (get_field('women_header_video'))?get_field('women_header_video'):"";
$women_video_code	= str_replace(array('https://vimeo.com/','https://www.vimeo.com/','http://vimeo.com/','http://www.vimeo.com/'),'',$women_video);
?>

	<div id="banner_inner" style="background: url('<?php echo $header_banner; ?>') no-repeat 0 0;">
		<div class="container">
			<div class="row">

				<div class="col-md-12">
					<div class="img famdynamics">
						<?php if( $women_video_code !=  "" ){ // width="684" height="385" ?>
						<iframe src="https://player.vimeo.com/video/<?php echo $women_video_code; ?>?title=0&byline=0&portrait=0" width="100%" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
						<?php } ?>
					</div>
				</div>
			</div>
		</div>
	</div>


	<div class="clearfix bussinesView text-center">
		<div class="container">
			<div class="row">
				<div class="col-md-7 sectionheadng bussinesViewLeft mrgTB20">
					<?php $women_below_header_sec = (get_field('women_below_header_sec'))?get_field('women_below_header_sec'):"";
					echo $women_below_header_sec;
					?>
				</div>
				<div class="col-md-5 clientreviewimg"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/bussinesView.png" /></div>
			</div>
		</div>
	</div>

	<div class="clearfix womensResources text-center">

		<div class="container">
			<div class="ResourcesTitle mrgTB20">
				<?php $womens_resources_title = (get_field('womens_resources_title'))?get_field('womens_resources_title'):"WOMENS RESOURCES"; ?>
				<h2><?php echo $womens_resources_title; ?></h2>
			</div>
			<?php
			// WP_Query arguments
			$args = array (
				'post_type'             => array( 'post' ),
				'post_status'           => array( 'publish' ),
				'cat'                   => '6',
				'post_count'			=> 8
			);

			// The Query
			$women_query = new WP_Query( $args );

			// The Loop
			if ( $women_query->have_posts() ) {
				echo '<div class="owl-carousel">';
				while ( $women_query->have_posts() ) {
					$women_query->the_post();
					if ( has_post_thumbnail() ) {
						$posturl = wp_get_attachment_url( get_post_thumbnail_id() );
					}else{
						$posturl = 'http://placehold.it/265x180';
					}
					?>
					<div class="item">
						<div class="findet">
							<div class="img">
								<img src="<?php echo $posturl;?>" /></div>
							<div class="DonnaRstrong">
								<div class="DonnaRs"><?php echo get_the_author()." / "; the_date();?></div>
								<h3><?php echo get_the_title(); ?></h3></div>
							<div class="Resources-COntent">
								<p><?php the_excerpt(); ?></p>
								<a href="<?php echo get_the_permalink(get_the_ID()); ?>" class="read_more">Read More</a>
							</div>
						</div>
					</div>
					<?php
				}
				?>
				</div>
				<script>
					jQuery( document).ready(function () {
						jQuery('.owl-carousel').owlCarousel({
							loop:true,
							margin:10,
							nav:true,
							responsive:{
								0:{
									items:1
								},
								600:{
									items:2
								},
								800:{
									items:3
								},
								1000:{
									items:4
								}
							}
						})
					});

				</script>
				<?php
			} else {
				// no posts found
			}

			// Restore original Post Data
			wp_reset_postdata();

			?>

		</div>

	</div>

	<!--WOMEN & RETIREMENT -->
	<?php
		$women_retire_sec_title = (get_field('women_retire_sec_title'))?get_field('women_retire_sec_title'):"WOMEN &amp; RETIREMENT";
		$women_retire_sec_subtitle = (get_field('women_retire_sec_subtitle'))?get_field('women_retire_sec_subtitle'):"WOMEN &amp; RETIREMENT";
		$women_retire_title = (get_field('women_retire_title'))?get_field('women_retire_title'):"";
		$women_retire_content = (get_field('women_retire_content'))?get_field('women_retire_content'):"";
	?>
	<div class="womenRetirement">
		<div class="container">
			<div class="retirementTitle">
				<h2><?php echo $women_retire_sec_title; ?></h2>
				<h5><?php echo $women_retire_sec_subtitle; ?></h5>
			</div>

			<div class="row">
				<div class="col-sm-7">
					<div class="womenRetirement-List">
						<?php
						if( have_rows('women_retire_steps') ){
							echo '<ul>';
							$li = 0;
							$li_default = array(
									'class' => "",
									'id' => "g710",
									'start' => "#ef8800",
									'end' => "#e70101",
							);
							$li_class = array(
								array(
									'class' => "",
									'id' => "g710",
									'start' => "#ef8800",
									'end' => "#e70101",
								),
								array(
									'class' => "takeTime",
									'id' => "g197",
									'start' => "#f8bd55",
									'end' => "#ec8e0a",
								),
								array(
									'class' => "saveLess",
									'id' => "g404",
									'start' => "#6cbe52",
									'end' => "#04a699",
								),
								array(
									'class' => "worseWomen",
									'id' => "g982",
									'start' => "#024f63",
									'end' => "#002c51",
								),
								array(
									'class' => "higherHealth",
									'id' => "g856",
									'start' => "#ef3f97",
									'end' => "#e4137c",
								),
								array(
									'class' => "myAdvisor",
									'id' => "g553",
									'start' => "#999999",
									'end' => "#666666",
								),
							);
						while ( have_rows('women_retire_steps') ) : the_row();
							$womenr_title	= get_sub_field('womenr_title');
							$womenr_content = get_sub_field('womenr_content');
							if( $womenr_title !=  "" ){
								$li_current = ($li_class[$li])?$li_class[$li]:$li_default;
							?>
								<li class="<?php echo $li_current['class']; ?>">
									<div class="retirementContnt">
										<h4><?php echo $womenr_title; ?></h4>
										<p><?php echo $womenr_content; ?></p>
									</div>
									<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 1 1" preserveAspectRatio="none">
										<linearGradient id="<?php echo $li_current['id']; ?>" gradientUnits="userSpaceOnUse" x1="0%" y1="0%" x2="100%" y2="0%">
											<stop stop-color="<?php echo $li_current['start']; ?>" offset="0"/><stop stop-color="<?php echo $li_current['end']; ?>" offset="1"/>
										</linearGradient>
										<rect x="0" y="0" width="1" height="1" fill="url(#<?php echo $li_current['id']; ?>)" />
									</svg>
								</li>
							<?php
							}
							$li++;
						endwhile;
						echo '</ul>';
						}
						?>
					</div>

				</div>
				<div class="col-sm-5">
					<div class="womenRetirement-Contnt">
						<h3><?php echo $women_retire_title; ?></h3>
						<p><?php echo $women_retire_content; ?></p>
					</div>

				</div>
			</div>

		</div>

	</div>
	<!--WOMEN & RETIREMENT -->

	<!--FINANCIAL PLANNING FOR WOMEN -->
	<div class="financialPlanning">
		<div class="container">
			<div class="financialPlanningTitle">
				<?php
				$women_fin_plan_sec_title = (get_field('women_fin_plan_sec_title'))?get_field('women_fin_plan_sec_title'):"FINANCIAL PLANNING FOR WOMEN";
				?>
				<h2><?php echo $women_fin_plan_sec_title;?></h2>
			</div>
			<?php
			if( have_rows('women_fin_plan_blocks' ) ){
				echo '<ul>';
				while ( have_rows('women_fin_plan_blocks') ) : the_row();
					$finplan_img = esc_url(get_sub_field('women_finplan_image'));
					$finplan_title = get_sub_field('women_finplan_title');
					if( $finplan_img !=  "" ){
						?>
						<li>
							<div class="planningWomen">
								<img src="<?php echo $finplan_img; ?>" alt="" />
								<span><?php echo $finplan_title; ?></span>
							</div>
						</li>
						<?php
					}
				endwhile;
				echo '</ul>';
			} ?>
		</div>

	</div>
	<!--FINANCIAL PLANNING FOR WOMEN -->

	<?php $women_above_callnow_sec = (get_field('women_above_callnow_sec'))?get_field('women_above_callnow_sec'):"";
	if( women_above_callnow_sec != ""){
		?>
		<div class="fullGray">
			<div class="container">
				<div class="grayContnt">
					<?php echo $women_above_callnow_sec; ?>
				</div>
			</div>
		</div>
		<?php
	}
?>



<?php
	$display_call_cta = (get_field('display_call_cta', get_the_ID()))?get_field('display_call_cta', get_the_ID()):get_field('display_call_cta', 'option');
if( $display_call_cta == '1'){

	$call_title = $call_subtitle = $call_mess_button_text = $call_tele_button_text = "";
	$call_mess_button_link = $call_tele_button_link = "";

	$call_title = (get_field('call_title', get_the_ID()))?get_field('call_title', get_the_ID()):get_field('call_title', 'option');
	$call_subtitle = (get_field('call_sub_title', get_the_ID()))?get_field('call_sub_title', get_the_ID()):get_field('call_sub_title', 'option');
	$call_tele_button_text = (get_field('call_tele_button_text', get_the_ID()))?get_field('call_tele_button_text', get_the_ID()):get_field('call_tele_button_text', 'option');
	$call_tele_button_link = (get_field('call_tele_button_link', get_the_ID()))?get_field('call_tele_button_link', get_the_ID()):get_field('call_tele_button_link', 'option');
	$call_mess_button_text = (get_field('call_mess_button_text', get_the_ID()))?get_field('call_mess_button_text', get_the_ID()):get_field('call_mess_button_text', 'option');
	$call_mess_button_link = (get_field('call_mess_button_link', get_the_ID()))?get_field('call_mess_button_link', get_the_ID()):get_field('call_mess_button_link', 'option');

	?>
	<div class="callNow-area">
		<div class="callNow-Box">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mobile-img"><img src="<?php echo get_template_directory_uri(); ?>/images/mobile-img.png" alt="" /></div>
					</div>

					<div class="col-md-8">
						<div class="callNow-Text">
							<h2><?php echo $call_title; ?></h2>
							<span><?php echo $call_subtitle; ?></span>
							<div class="Message-Callus">
								<a href="<?php echo $call_tele_button_link; ?>"><span class="call-icon"></span><?php echo $call_tele_button_text; ?></a>
								<a href="<?php echo $call_mess_button_link; ?>"><span class="message-icon"></span><?php echo $call_mess_button_text; ?></a>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
	<?php
}
?>


</div>

<?php

$client_title = (get_field('client_title', get_the_ID()))?get_field('client_title', get_the_ID()):get_field('client_title', 'option');
if ($client_title == ""){
	$client_title = "<span>WHAT OUR</span> CLIENTS SAY";
}
?>
<div class="whitebg text-center padTB30 clientSaybg" style="background:#fff !important;">
	<div class="container">
		<div class="clientSayTitle">
			<h2><?php echo $client_title; ?></h2>
		</div>
		<div class="clientSay">
			<?php
			if( have_rows('clients_test_videos', get_the_ID()) ){
				echo '<div class="owl-carousel1">';
				while ( have_rows('clients_test_videos') ) : the_row();
					$video_url	= get_sub_field('test_video_url');
					$video_code	= str_replace(array('https://vimeo.com/','https://www.vimeo.com/','http://vimeo.com/','http://www.vimeo.com/'),'',$video_url);
					if( $video_code !=  "" ){
						?>
						<div class="item">
							<div class="clientVideo">
								<iframe style="width:100%;" src="https://player.vimeo.com/video/<?php echo $video_code; ?>?title=0&byline=0&portrait=0" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
							</div>
						</div>
						<?php
					}
				endwhile;
				echo '</div>';
			}else{
				if( have_rows('clients_test_videos', 'options' ) ){
					echo '<div class="owl-carousel1">';
					while ( have_rows('clients_test_videos', 'options') ) : the_row();
						$video_url	= get_sub_field('test_video_url', 'options');
						$video_code	= str_replace(array('https://vimeo.com/','https://www.vimeo.com/','http://vimeo.com/','http://www.vimeo.com/'),'',$video_url);
						if( $video_code !=  "" ){
							?>
							<div class="item">
								<div class="clientVideo">
									<iframe style="width:100%;" src="https://player.vimeo.com/video/<?php echo $video_code; ?>?title=0&byline=0&portrait=0" height="290" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
								</div>
							</div>
							<?php
						}
					endwhile;
					echo '</div>';
				}
			}


			?>

			</div>

		</div>

	</div>
</div>

	<script>
		jQuery(document).ready( function () {
			jQuery('.owl-carousel1').owlCarousel({
				loop:true,
				margin:10,
				nav:true,
				responsive:{
					0:{
						items:1
					},
					600:{
						items:2
					},
					800:{
						items:3
					},
					1000:{
						items:3
					}
				}
			});

			(function($){
				$(window).on("load",function(){
					$("#content-1,#content-2,#content-3,#content-4,#content-5").mCustomScrollbar({
						theme:"minimal"
					});
				});
			})(jQuery);
		});
	</script>

<?php //get_sidebar() ?>

<?php get_footer() ?>