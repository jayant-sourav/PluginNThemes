<?php
/*
Template Name: Subscription
*/
get_header();
the_post();
?>

<?php
$subscr_header_image  = ( get_field('subscr_header_image'))?get_field('subscr_header_image'):"";
$subscr_header_title  = ( get_field('subscr_header_title'))?get_field('subscr_header_title'):"UNLIMITED FINANCIAL ADVICE FOR A FLAT MONTHLY FEE.";
?>
<div class="subscription-Banner" style="<?php if($subscr_header_image !="") { echo "background: url('".esc_url($subscr_header_image)."') no-repeat center 0; background-size: cover;"; } ?>" >
	<div class="container">
    	<div class="banenrText"><?php echo $subscr_header_title; ?></div>
    </div>
</div>

<?php
	if( have_rows('subscription_packages') ){
		echo '<div class="container annual-report"><div class="row">';
		$i = 0;
		while ( have_rows('subscription_packages') ) : the_row();

			$sub_pack_amount = (get_sub_field('sub_pack_amount'))?get_sub_field('sub_pack_amount'): "";
			$sub_pack_title = (get_sub_field('sub_pack_title'))?get_sub_field('sub_pack_title'): "";
			$sub_pack_cart_link = (get_sub_field('sub_pack_cart_link'))?get_sub_field('sub_pack_cart_link'): "";
			$sub_pack_condition = (get_sub_field('sub_pack_condition'))?get_sub_field('sub_pack_condition'): "Must be 18+ years of age";
			if( $sub_pack_amount !=  "" ){
				?>
				<div class="col-sm-4">
		    	<div class="annual-count">
		        	<div class="yearBg <?php if( $i == 1){ echo ' annual-bg'; } if( $i == 2){ echo ' individual-consultation-bg'; } ?>" >
		            <strong><?php echo $sub_pack_amount; ?></strong>
		            <span><?php echo $sub_pack_title; ?></span>
		            </div>
		            <div class="yearContnt">
									<?php if( $i == 2){
										echo '<h3>Advice on:</h3>';
									} ?>
									<?php if( have_rows('sub_pack_benefites') ){
										echo '<ul>';
												while( have_rows('sub_pack_benefites') ): the_row();
												?>
												<li><?php the_sub_field('sub_pack_sub_benefit'); ?></li>
												<?php
												endwhile;
										echo '</ul>';
									}
								?>
		            <div class="add-to-cart"><a href="<?php echo esc_url($sub_pack_cart_link); ?>">ADD TO CART</a>
		            <span><?php echo $sub_pack_condition; ?></span>
		            </div>
		            </div>
		        </div>
		    </div>
				<?php
			}
			$i++;
		endwhile;
		echo '</div></div>';
	}
?>

<?php
	if( have_rows('sub_middle_section') ){
		while ( have_rows('sub_middle_section') ) : the_row();
			$sub_middle_image = (get_sub_field('sub_middle_image'))?get_sub_field('sub_middle_image'): "";
			$sub_middle_title = (get_sub_field('sub_middle_title'))?get_sub_field('sub_middle_title'): "";
			$sub_middle_content = (get_sub_field('sub_middle_content'))?get_sub_field('sub_middle_content'): "";
			if( $sub_middle_title !=  "" ){
				?>
				<div class="become-a-member">
					<div class="become-member-img" style="<?php if( $sub_middle_image !=""){ echo "background: url('".$sub_middle_image."'); background-position: center 0; background-size: cover;"; } ?>"></div>
					<div class="become-member-content">
						<div class="BM-contnt">
							<h2><?php echo $sub_middle_title; ?></h2>
							<?php echo $sub_middle_content; ?>
						</div>
					</div>
				</div>
				<?php
			}
		endwhile;
	}
?>

<?php
// Render Financial Advice Box
	if( have_rows('financial_advice_box') ){
		echo '<div class="financial-advice-Box-area"><div class="container">';
		echo '<ul>';
		while ( have_rows('financial_advice_box') ) : the_row();
			$financial_advice_image = (get_sub_field('financial_advice_image'))?get_sub_field('financial_advice_image'): "http://placehold.it/156x144";
			$financial_advice_title = (get_sub_field('financial_advice_title')) ? get_sub_field('financial_advice_title'): "";
			$financial_advice_content = (get_sub_field('financial_advice_content')) ? get_sub_field('financial_advice_content') : "";
			if( $financial_advice_title !=  "" ){
				?>
				<li>
					<div class="Fadvice-img">
							<img src="<?php echo esc_url($financial_advice_image); ?>" alt="<?php echo $financial_advice_title; ?>" />
						</div>
						<div class="Fadvice-Contnt">
							<h3><?php echo $financial_advice_title; ?></h3>
								<p><?php echo $financial_advice_content; ?></p>
						</div>
				</li>
				<?php
			}
		endwhile;
		echo '</ul>';
		echo '</div></div>';
	}
?>


<?php
// Render Call Now
if( function_exists('render_call_now_sections') ){
	render_call_now_sections();
}
?>
</div>

<div class="tabsArea">
<div class="container" style="background:#fff;">
<div id="verticalTab">
	<?php
		if( have_rows('subscr_footer_tab_area') ){
			echo '<ul class="resp-tabs-list">';
			while ( have_rows('subscr_footer_tab_area') ) : the_row();
				$subscr_footer_tab_title  = (get_sub_field('subscr_footer_tab_title')) ?get_sub_field('subscr_footer_tab_title'): "";
				if( $subscr_footer_tab_title !=  "" ){
					?>
					<li><?php echo $subscr_footer_tab_title; ?></li>
					<?php
				}
			endwhile;
			echo '</ul>';
		}
	?>

	<?php
		if( have_rows('subscr_footer_tab_area') ){
			echo '<div class="resp-tabs-container">';
			while ( have_rows('subscr_footer_tab_area') ) : the_row();
				$subscr_footer_tab_image = (get_sub_field('subscr_footer_tab_image')) ?get_sub_field('subscr_footer_tab_image'): "";
				$subscr_footer_tab_content = (get_sub_field('subscr_footer_tab_content')) ?get_sub_field('subscr_footer_tab_content'): "";
				if( $subscr_footer_tab_content !=  "" ){
					?>
					<div>
						<?php if( $subscr_footer_tab_image != ""){ ?>
							<div class="businessImg"><img src="<?php echo $subscr_footer_tab_image; ?>" alt="" /></div>
						<?php } ?>
						<p><?php echo $subscr_footer_tab_content; ?></p>
					</div>
					<?php
				}
			endwhile;
			echo '</div>';
		}
	?>
</div>
</div>
</div>

<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/tab.css">
<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/tab.js"></script>
<script>
jQuery(document).ready(function () {
	jQuery('#horizontalTab').easyResponsiveTabs({
		type: 'default', //Types: default, vertical, accordion
		width: 'auto', //auto or any width like 600px
		fit: true,   // 100% fit in a container
		closed: 'accordion', // Start closed if in accordion view
		activate: function(event) { // Callback function if tab is switched
			var $tab = jQuery(this);
			var $info = jQuery('#tabInfo');
			var $name = jQuery('span', $info);
			$name.text($tab.text());
			$info.show();
		}
	});
	jQuery('#verticalTab').easyResponsiveTabs({
		type: 'vertical',
		width: 'auto',
		fit: true
	});
});
</script>

<?php //get_sidebar() ?>
<?php get_footer() ?>
