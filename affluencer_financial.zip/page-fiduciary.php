<?php
/*
Template Name: Fiduciary Financial Advice
*/
get_header();
the_post();
?>

<?php
$header_image  = ( get_field('header_image') )?get_field('header_image'):get_stylesheet_directory_uri()."/images/fiduciary-banner.jpg";
$header_title  = ( get_field('header_title') )?get_field('header_title'):'The highest level of<br /><span>care</span> in the industy.';
$header_subtitle  = ( get_field('header_subtitle') )?get_field('header_subtitle'):'';
$header_content = ( get_field('header_content') )?get_field('header_content'):'';
?>
<div class="fiduciary-banner">
	<img src="<?php echo esc_url($header_image); ?>" alt="" />
    <div class="bannerText right_100"><?php echo $header_title; ?></div>
</div>

<?php
$fidu_middle_sec_title  = ( get_field('fidu_middle_sec_title') )?get_field('fidu_middle_sec_title'): 'WHAT IS A FIDUCIARY AND WHY SHOULD I CARE?';
$fidu_middle_sec_image  = ( get_field('fidu_middle_sec_image') )?get_field('fidu_middle_sec_image'): get_stylesheet_directory_uri()."/images/fiduciary-Content-img.jpg";
$fidu_middle_sec_content  = ( get_field('fidu_middle_sec_content') )?get_field('fidu_middle_sec_content'): '';
$fidu_footer_sec_content  = ( get_field('fidu_footer_sec_content') )?get_field('fidu_footer_sec_content'): '';
?>
<div class="fiduciary-Content">
  <div class="container">
    <h2><?php echo $fidu_middle_sec_title; ?></h2>
    <div class="fiduciaryContntImg">
    	<img src="<?php echo esc_url($fidu_middle_sec_image); ?>" alt="" />
    </div>
		<?php echo $fidu_middle_sec_content; ?>
  </div>
</div>

<div class="fiduciary-video">
	<div class="container">
		<?php
		if( have_rows('fidu_footer_vid_sec') ){
			echo '<ul>';
			while ( have_rows('fidu_footer_vid_sec') ) : the_row();
				$video_url	= get_sub_field('fidu_video_url');
				$video_code	= str_replace( array( 'https://youtube.com/watch?v=', 'https://www.youtube.com/watch?v=', 'http://youtube.com/watch?v=', 'http://www.youtube.com/watch?v=' ), '', $video_url);
				if( $video_code !=  "" ){
					?>
						<li>
							<iframe width="100%" height="250" src="https://www.youtube.com/embed/<?php echo $video_code; ?>" frameborder="0" allowfullscreen></iframe>
						</li>
					<?php
				}
			endwhile;
			echo '</ul>';
		} ?>
  </div>
</div>

<?php
// Render Call Now
if( function_exists('render_call_now_sections') ){
	render_call_now_sections();
}
?>

<div class="textContent" style="background:#fff;">
<div class=" container">
<p><?php echo $fidu_footer_sec_content; ?></p>
</div>
</div>

</div>

<?php //get_sidebar() ?>
<?php get_footer() ?>
