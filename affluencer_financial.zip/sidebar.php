<div class="col-sm-3 cal-sidebar">
 <div class="blogRight">

		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>

		<?php endif; ?>
	</div><!-- #sidebar -->
</div>
