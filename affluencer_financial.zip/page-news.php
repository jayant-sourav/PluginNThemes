<?php
/*
Template Name: In The News
*/
get_header();
the_post();
?>

<?php
$header_image  = ( get_field('header_image') )?get_field('header_image'):get_stylesheet_directory_uri()."/images/news-banner.jpg";
$header_title  = ( get_field('header_title') )?get_field('header_title'):'NEWS & MEDIA APPEARANCES';
$header_subtitle  = ( get_field('header_subtitle') )?get_field('header_subtitle'):'WE PROVIDE TV AND RADIO PERSONALITY FINANCIAL ADVISORS FOR EXPERT COMMENTARY ON TV, RADIO AND PRINT.';
$header_content = ( get_field('header_content') )?get_field('header_content'):'';
?>
<div class="news-banner">
<div class="based-financial-Img">
<img src="<?php echo esc_url($header_image); ?>" alt="<?php echo $header_title; ?>" />
<div class="based-findText"><?php echo $header_title; ?></div>
</div>
</div>

<div class="container">
	<div class="news-contant">
		<h3><?php echo $header_subtitle; ?></h3>
		<p><?php echo $header_content; ?></p>
	</div>
</div>

<div class="onTv-Movie">
	<div class="container">
		<h2>ON TV & MOVIES</h2>
		<div class="TvMovie">
			<?php
			$dsp = 0;
		if( have_rows('xt_video_section') ){
			echo '<div class="owl-carousel1">';
			while ( have_rows('xt_video_section') ) : the_row();
				$video_code = '';
				$video_url	= get_sub_field('xt_video_url');

				if( $dsp %2 == 0 ){
					echo '<div class="item">';
				}

				if( false !== strpos( $video_url, 'youtube.com' ) ){
					$video_code	= str_replace( array( 'https://youtube.com/watch?v=', 'https://www.youtube.com/watch?v=', 'http://youtube.com/watch?v=', 'http://www.youtube.com/watch?v=' ), '', $video_url);
					if( $video_code !=  "" ){
						?>
							<div class="clientVideo">
							<iframe style="max-width: 100%;" width="422" height="270" src="https://www.youtube.com/embed/<?php echo $video_code; ?>" frameborder="0" allowfullscreen></iframe>
							</div>
						<?php
					}
					
				}elseif(false !== strpos( $video_url, 'vimeo.com' ) ){
					$video_code	= str_replace(array('https://vimeo.com/','https://www.vimeo.com/','http://vimeo.com/','http://www.vimeo.com/'),'',$video_url);
					if( $video_code !=  "" ){
						?>
							<div class="clientVideo">
							<iframe style="max-width: 100%; width: 422px;" src="https://player.vimeo.com/video/<?php echo $video_code; ?>?title=0&byline=0&portrait=0" height="270" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>
						<?php
					}
				}

				if( ($dsp + 1) % 2 == 0 ){
					echo '</div>';
				}
				$dsp++;
			endwhile;

			if( ($dsp + 1) % 2 == 0 ){
				echo '</div>';
			}

			echo '</div>';
		} ?>				 
		</div>
		<script>
			jQuery( document).ready(function () {
				jQuery('.owl-carousel1').owlCarousel({
					loop:true,
					margin:10,
					nav:false,
					dots: true,
					responsive:{
					0:{
					    items:1
					},
					600:{
					    items:2
					},
					800:{
					    items:3
					},
					1000:{
					    items:3
					}
					}
				});
			});
		</script>
	</div>
</div>

<div class="radio">
<div class="container">
<h2>RADIO</h2>
<div class="TvMovie">
<div class="owl-carousel2">

<?php 
if( have_rows('xt_radio_section') ){
	$dsp2 = 0;
	while ( have_rows('xt_radio_section') ) : the_row();
		$xt_audio_image	= (get_sub_field('xt_audio_image'))? get_sub_field('xt_audio_image') : 'http://placehold.it/350x207';
		$xt_audio_name	= get_sub_field('xt_audio_name');
		$xt_audio_url	= get_sub_field('xt_audio_url');

		if( $dsp2 % 2 == 0 ){
			echo '<div class="item">';
		}
		?>
		<div class="clientVideo">
			<a href="<?php echo esc_url($xt_audio_url); ?>" target="_blank" >
			<img src="<?php echo esc_url($xt_audio_image); ?>" alt="" />
			<span><?php echo $xt_audio_name; ?></span>
			</a>
		</div>
		<?php
		if( ($dsp2 + 1) % 2 == 0 ){
			echo '</div>';
		}
		$dsp2++;

	endwhile;
	if( ($dsp2 + 1) % 2 == 0 ){
		echo '</div>';
	}
}
?>

</div>
</div>

<script>
	jQuery( document).ready(function () {
		jQuery('.owl-carousel2').owlCarousel({
			loop:true,
			margin:10,
			nav:true,
			dots: false,
			responsive:{
			0:{
			    items:1
			},
			600:{
			    items:2
			},
			800:{
			    items:3
			},
			1000:{
			    items:3
			}
			}
		});
	});
</script>

</div>    
</div>

<div class="clearfix womensResources text-center NewsArticles">
	<div class="container">
		<div class="ResourcesTitle mrgTB20">
			<h2>NEWS ARTICLES</h2>
		</div>

		<?php
			// WP_Query arguments
			$args = array (
				'post_type'              => array( 'post' ),
				'post_status'            => array( 'publish' ),
				'posts_per_page'         => -1,
			);

			// The Query
			$women_query = new WP_Query( $args );

			// The Loop
			if ( $women_query->have_posts() ) {
				echo '<div class="owl-carousel">';
				while ( $women_query->have_posts() ) {
					$women_query->the_post();
					if ( has_post_thumbnail() ) {
						$posturl = wp_get_attachment_url( get_post_thumbnail_id() );
					}else{
						$posturl = 'http://placehold.it/265x180';
					}
					?>
					<div class="item">
						<div class="findet">
							<div class="img">
								<img src="<?php echo $posturl;?>" /></div>
							<div class="DonnaRstrong">
								<div class="DonnaRs"><?php echo get_the_author()." / "; the_date();?></div>
								<h3><?php echo get_the_title(); ?></h3></div>
							<div class="Resources-COntent">
								<p><?php the_excerpt(); ?></p>
								<a href="<?php echo get_the_permalink(get_the_ID()); ?>" class="read_more">Read More</a>
							</div>
						</div>
					</div>
					<?php
				}
				?>
				</div>
				<script>
					jQuery( document).ready(function () {
						jQuery('.owl-carousel').owlCarousel({
							loop:true,
							margin:10,
							nav:true,
							responsive:{
								0:{
									items:1
								},
								600:{
									items:2
								},
								800:{
									items:3
								},
								1000:{
									items:4
								}
							}
						})
					});

				</script>
				<?php
			} else {
				// no posts found
			}

			// Restore original Post Data
			wp_reset_postdata();

			?>		
    </div>
</div>
<style>
.whitebg .footertoppart, footer {
    background-color: transparent !important;
}
</style>

<?php //get_sidebar() ?>
<?php get_footer() ?>
