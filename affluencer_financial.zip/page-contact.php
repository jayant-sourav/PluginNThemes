<?php
/*
Template Name: Contact Us.
*/
get_header();
the_post();
?>

<?php
$header_image  = ( get_field('header_image') )?get_field('header_image'):get_stylesheet_directory_uri()."/images/contact-banner.jpg";
$header_title  = ( get_field('header_title') )?get_field('header_title'):'AFFLUENCER FINANCIAL';
$header_subtitle  = ( get_field('header_subtitle') )?get_field('header_subtitle'):'LOS ANGELES HEADQUARTERS';
$header_content = ( get_field('header_content') )?get_field('header_content'):'';
?>

<div class="fiduciary-banner">
	<img src="<?php echo esc_url($header_image); ?>" alt="" />
</div>

<div class="affluencer-financial">
<div class="container">
<h2><b><?php echo $header_title; ?></b></h2>
<span><?php echo $header_subtitle; ?></span>
<p><?php echo $header_content; ?></p>
</div>
</div>
<?php
$contact_phone  = ( get_field('contact_phone') )?get_field('contact_phone'):'310-730-1330';
$contact_email  = ( get_field('contact_email') )?get_field('contact_email'):'info@affluencer.com';
$contact_address = ( get_field('contact_address') )?get_field('contact_address'):'';
?>
<div class="contactAdd">
	<div class="container">
    	<ul>
        	<li><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/phone-icon-cntct.jpg" alt="" />
            <div class="contnt-address">
            <div class="address"><p>WE ARE ON 24/7</p>
            <strong><?php echo $contact_phone; ?></strong></div>
            </div>
            </li>
            <li><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/massage-icon.jpg" alt="" />
            <div class="contnt-address">
            <div class="address">
            <p>SEND US EMAIL ON</p>
            <a href="mailto:<?php echo $contact_email; ?>"><?php echo $contact_email; ?></a>
            </div>
            </div>
            </li>
            <li><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/location-icon.jpg" alt="" />
            <div class="contnt-address">
            <div class="address">
            <p><?php echo $contact_address; ?> </p>
            </div>
            </div>
            </li>
        </ul>
    </div>
</div>

<div class="send-a-message">
	<div class="container">
    	<h2><b>SEND US A MESSAGE</b></h2>
        <div class="send-mess-area">
					<?php the_field('contact_form'); ?>
        </div>
    </div>
</div>


<?php
	if( have_rows('contact_sections') ){
		?>
		<div class="contactFinancial">
			<div class="container">
		    	<ul>
						<?php
						while ( have_rows('contact_sections') ) : the_row();
							$contact_sec_image = (get_sub_field('contact_sec_image'))?get_sub_field('contact_sec_image'): "";
							$contact_sec_title = (get_sub_field('contact_sec_title'))?get_sub_field('contact_sec_title'): "";
								?>
								<li>
			            <div class="FinancialBox">
			            <img src="<?php echo esc_url($contact_sec_image); ?>" alt="<?php echo $contact_sec_title; ?>" />
			            <span><?php echo $contact_sec_title; ?></span>
			            </div>
			          </li>
								<?php
						endwhile;
						?>
				</ul>
			</div>
		</div>
		<?php
	}

$display_call_cta = (get_field('display_call_cta', get_the_ID()))?get_field('display_call_cta', get_the_ID()):get_field('display_call_cta', 'option');
if( $display_call_cta == '1'){

    $call_title = $call_subtitle = $call_mess_button_text = $call_tele_button_text = "";
    $call_mess_button_link = $call_tele_button_link = "";

    $call_title = (get_field('call_title', get_the_ID()))?get_field('call_title', get_the_ID()):get_field('call_title', 'option');
    $call_subtitle = (get_field('call_sub_title', get_the_ID()))?get_field('call_sub_title', get_the_ID()):get_field('call_sub_title', 'option');
    $call_tele_button_text = (get_field('call_tele_button_text', get_the_ID()))?get_field('call_tele_button_text', get_the_ID()):get_field('call_tele_button_text', 'option');
    $call_tele_button_link = (get_field('call_tele_button_link', get_the_ID()))?get_field('call_tele_button_link', get_the_ID()):get_field('call_tele_button_link', 'option');
    $call_mess_button_text = (get_field('call_mess_button_text', get_the_ID()))?get_field('call_mess_button_text', get_the_ID()):get_field('call_mess_button_text', 'option');
    $call_mess_button_link = (get_field('call_mess_button_link', get_the_ID()))?get_field('call_mess_button_link', get_the_ID()):get_field('call_mess_button_link', 'option');
    ?>
		<div class="callNow-area callNow-girl">
			<div class="callNow-Box">
		    	<div class="container">
		        <div class="row">
		        <div class="col-md-3">
		        	<div class="mobile-img"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/call-img.png" alt="" /></div>
		        </div>

		        <div class="col-md-8">
		         <div class="callNow-Text">
							 <h2><?php echo $call_title; ?></h2>
 							<span><?php echo $call_subtitle; ?></span>
 							<div class="Message-Callus">
 									<a href="<?php echo $call_tele_button_link; ?>"><span class="call-icon"></span><?php echo $call_tele_button_text; ?></a>
 									<a href="<?php echo $call_mess_button_link; ?>"><span class="message-icon"></span><?php echo $call_mess_button_text; ?></a>
 							</div>
		         </div>
		        </div>

		        </div>
		        </div>
		    </div>
		</div>
    <?php
}

// Render Footer Video Testimonials
if( function_exists('render_video_testimonials_footer_section') ){
	render_video_testimonials_footer_section();
}
?>
<?php get_footer() ?>