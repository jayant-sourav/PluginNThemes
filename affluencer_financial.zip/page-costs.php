<?php
/*
Template Name: Costs
*/
get_header();
the_post();
?>

<?php
$header_image  = ( get_field('header_image') )?get_field('header_image'):get_stylesheet_directory_uri()."/images/costs-banner.jpg";
$header_title  = ( get_field('header_title') )?get_field('header_title'):'OUR PROMISE';
$header_subtitle  = ( get_field('header_subtitle') )?get_field('header_subtitle'):'At Affluencer Financial <br />We Focus On Pure Advice <br />And No Sales.';
$header_content = ( get_field('header_content') )?get_field('header_content'):'';
?>

<div class="costs-banner">
	<img src="<?php echo esc_url($header_image); ?>" alt="<?php echo $header_title; ?>" />
    <div class="bannerText">
    <h2><?php echo $header_title; ?></h2>
    <p><?php echo $header_subtitle; ?></p>
    </div>
</div>

<?php
	if( have_rows('cost_fee_sections') ){
		echo '<div class="flat-hourly">';
		$i = 0;
		while ( have_rows('cost_fee_sections') ) : the_row();

			$cost_fee_title = (get_sub_field('cost_fee_title'))?get_sub_field('cost_fee_title'): "";
			$cost_fee_fee = (get_sub_field('cost_fee_fee'))?get_sub_field('cost_fee_fee'): "";
			$cost_fee_content = (get_sub_field('cost_fee_content'))?get_sub_field('cost_fee_content'): "";

			if( $cost_fee_title !=  "" ){
				?>
				<div class="<?php if( $i %2 == 0 ){ echo 'flat-fee'; }else{ echo 'hourly'; } ?>">
					<div class="flat-fee-contnt">
						<div class="Htitle">
							<h2><?php echo $cost_fee_title; ?></h2>
							<span><?php echo $cost_fee_fee; ?></span>
						</div>
						<?php echo $cost_fee_content; ?>
					</div>
				</div>
				<?php
			}
			$i++;
		endwhile;
		echo '</div>';
	}
?>

<?php
	if( have_rows('cost_sections') ){
		echo '<div class="estatePlann">';
		$i = 0;
		while ( have_rows('cost_sections') ) : the_row();

			$cost_sec_image = (get_sub_field('cost_sec_image'))?get_sub_field('cost_sec_image'): "";
			$cost_sec_title = (get_sub_field('cost_sec_title'))?get_sub_field('cost_sec_title'): "";
			$cost_sec_content = (get_sub_field('cost_sec_content'))?get_sub_field('cost_sec_content'): "";

			if( $cost_sec_title !=  "" ){
				if( $i == 0 ){
					?>
					<div class="based-financial">
					<div class="based-financial-Img">
						<img src="<?php echo $cost_sec_image; ?>" alt="<?php echo $cost_sec_title; ?>" />
						<div class="based-findText"><?php echo $cost_sec_title; ?></div>
					</div>
					<div class="container">
						<div class="based-contant">
							<?php echo $cost_sec_content; ?>
						</div>
					</div>
					</div>
					<?php
				} elseif ( $i == 1) {
					?>
					<div class="portfolio-financial">
						<img src="<?php echo $cost_sec_image; ?>" alt="<?php echo $cost_sec_title; ?>" />
						<div class="portfolio-left">
							<div class="container"><h2><?php echo $cost_sec_title; ?></h2>
							</div>
						</div>
					</div>
					<?php
				}else{
					?>
					<div class="based-financial-planing">
						<div class="container">
						<h2><?php echo $cost_sec_title; ?></h2>
						<div class="based-financial-planing-contant">
							<?php echo $cost_sec_content; ?></div>
						<div class="based-financial-planing-right" style="<?php if($cost_sec_image !=""){ echo "background: url('".esc_url($cost_sec_image)."') no-repeat center;"; } ?>"></div>
						</div>
					</div>
					<?php
				}
			}
			$i++;
		endwhile;
		echo '</div>';
	}
?>

</div>

<?php
$cost_footer_sec_bg = (get_field('cost_footer_sec_bg'))?get_field('cost_footer_sec_bg'):"";
$cost_footer_sec_title = (get_field('cost_footer_sec_title'))?get_field('cost_footer_sec_title'):"ESTATE PLANNING MADE EASY";
$cost_footer_sec_button = (get_field('cost_footer_sec_button'))?get_field('cost_footer_sec_button'):"CONTACT US";
$cost_footer_sec_but_link = (get_field('cost_footer_sec_but_link'))?get_field('cost_footer_sec_but_link'):"#";
/* style="<?php if($cost_footer_sec_bg !=""){ echo "background: url('".esc_url($cost_footer_sec_bg)."') no-repeat;background-size: cover;"; } ?>" */
?>
<div class="made-easy-bg-img independent-financial-advice-img">
<div class="container">
	<h2><?php echo $cost_footer_sec_title; ?></h2>
    <div class="appointment-btn"><a href="<?php echo esc_url($cost_footer_sec_but_link); ?>"><?php echo $cost_footer_sec_button; ?></a></div>

		<?php
		if( have_rows('cost_footer_services') ){
			echo '<div class="made-easy"><ul>';
			$i = 0;
			while ( have_rows('cost_footer_services') ) : the_row();
			$cost_footer_ser_image = (get_sub_field('cost_footer_ser_image'))?get_sub_field('cost_footer_ser_image'):"";
			$cost_footer_ser_title = (get_sub_field('cost_footer_ser_title'))?get_sub_field('cost_footer_ser_title'):"";
			?>
			<li>
				<img src="<?php echo esc_url($cost_footer_ser_image); ?>" alt="<?php echo $cost_footer_ser_title; ?>" />
				<span><?php echo $cost_footer_ser_title; ?></span>
			</li>
			<?php
			endwhile;
			echo '</ul></div>';
		}
		?>

</div>
</div>
<style>
.whitebg .footertoppart, footer {
    background-color: transparent !important;
}
</style>


<?php //get_sidebar() ?>
<?php get_footer() ?>
