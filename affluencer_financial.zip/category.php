<?php get_header() ?>

<?php get_template_part( 'content' ); ?>

<?php get_footer() ?>
