<?php get_header() ?>

<div class="blogPage">
	<div class="container blogArea">
		<div class="row">
			 <div class="col-sm-9">
					<?php if ( have_posts() ) : ?>
						<?php while ( have_posts() ) : the_post() ?>
						<div id="post-<?php the_ID() ?>" class="post blogContnt">
							<?php   if ( has_post_thumbnail() ) {
										$url = wp_get_attachment_url( get_post_thumbnail_id() );
										echo '<div class="BlogImg"><img src="'.esc_url( $url ).'" alt="" /></div>';
								} ?>
							<div class="blogtitle">
								<h3 class="post-title"><a href="<?php the_permalink() ?>" title="<?php the_title() ?>" rel="bookmark"><?php the_title() ?></a></h3>
							</div>
							<div class="blogContent">
								<?php the_content(); ?>
								<?php echo eo_get_the_start( 'jS M Y' ); ?>
								<?php echo eo_get_the_end( 'jS M Y' ); ?>
								<?php echo eo_get_venue_name(); ?>
								<?php echo eo_get_booking_form(); ?>
								<?php
									$venueAddress	= urlencode(eo_get_venue_name());

									if($venueAddress != ''){
								?>
								<hr />
								<iframe width="100%" height="450" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?q=<?php echo urlencode(eo_get_venue_name()); ?>&key=AIzaSyDCzr13SZ8BlUdva_q3nnWNCdTQgMpNBuQ"></iframe>
								<?php } ?>
							</div>
						</div><!-- .post -->
						<?php endwhile; ?>
					<?php endif; ?>
				</div>
				<?php get_sidebar() ?>
		</div>
	</div>
</div>
<style>
.whitebg .footertoppart, footer {
		background-color: transparent !important;
}
</style>
<?php get_footer() ?>
