<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width">
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<meta name="description" content="<?php bloginfo('description') ?>" />
	<title><?php bloginfo('name'); ?> <?php if ( is_single() ) { ?> &raquo; Blog Archive <?php } ?> <?php wp_title(); ?></title>
	<link href='https://fonts.googleapis.com/css?family=Lato:400,100,100italic,300italic,300,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/responsive.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/uikit.css">
	
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> Comments RSS Feed" href="<?php bloginfo('comments_rss2_url') ?>"  />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php wp_head() ?>
</head>
<body>
<nav class="pushy pushy-left">
  <ul>
	<?php
		$items1 = wp_get_nav_menu_items('Main Menu Left');
		$items2 = wp_get_nav_menu_items('Main Menu Right');
	?>
	<li><a href="<?php echo $items1[0]->url; ?>"><svg height="22" width="63">
              <defs style="

          height=height 30px;=30px;

          width=width 30px;=30px;

          border=border 1px=1px solid=solid #fff;=#fff;

          =">

                <linearGradient id="gradm1" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm1)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[0]->title; ?></text>

              <?php echo $items1[0]->title; ?> </svg></a>

              </li>

            <li><a href="<?php echo $items1[1]->url; ?>"> <svg height="22" width="96">

              <defs style="height: 30px;width=" 30px;border="border: 1px solid;">

                <linearGradient id="gradm2" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm2)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[1]->title; ?> </text>

              <?php echo $items1[1]->title; ?> </svg> </a></li>

               <li><a href="<?php echo $items1[2]->url; ?>"> <svg height="22" width="86">

              <defs style="height: 30px;width=" 30px;border="border: 1px solid;">

                <linearGradient id="gradm3" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm3)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[2]->title; ?></text>

              <?php echo $items1[2]->title; ?> </svg> </a></li>

            

           <li><a href="<?php echo $items1[3]->url; ?>"> <svg height="22" width="62">

              <defs style="height: 30px;width=" 30px;border="border: 1px solid;">

                <linearGradient id="gradm4" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm4)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[3]->title; ?> </text>

              <?php echo $items1[3]->title; ?> </svg> </a></li>

     <li><a href="<?php echo $items2[0]->url; ?>"> <svg height="22" width="78">

              <defs style="height: 30px;width=" 30px;border="border: 1px solid;">

                <linearGradient id="gradm5" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm5)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[0]->title; ?> </text>

              <?php echo $items2[0]->title; ?> </svg> </a></li>

             <li><a href="<?php echo $items2[1]->url; ?>"> <svg height="22" width="110">

              <defs style="height: 30px;width=" 30px;border="border: 1px solid;">

                <linearGradient id="gradm6" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm6)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[1]->title; ?> </text>

              <?php echo $items2[1]->title; ?> </svg> </a></li>

               <li><a href="<?php echo $items2[2]->url; ?>"> <svg height="22" width="125">

              <defs style="height: 30px;width=" 30px;border="border: 1px solid;">

                <linearGradient id="gradm7" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm7)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[2]->title; ?> </text>

              <?php echo $items2[2]->title; ?> </svg> </a></li>

           <li><a href="<?php echo $items2[3]->url; ?>"> <svg height="22" width="93">

              <defs style="height: 30px;width=" 30px;border="border: 1px solid;">

                <linearGradient id="gradm8" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm8)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[3]->title; ?></text>

              <?php echo $items2[3]->title; ?> </svg> </a></li>

	</ul>

</nav>

<div class="site-overlay"></div>

<header id="top-bar" class="clearfix">

  <div class="mobileheader headrin">

    <div class="logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img title="OTH" src="<?php echo get_template_directory_uri(); ?>/images/logo.png"/></a>

      <hr class="left-top-line">

      </hr>

      <hr class="left-bottom-line">

      </hr>

    </div>

    <div class="menu-btn"> </div>

    <h1 class="text-center"><svg height="40" width="480">

              <defs style="

          height=height 30px;=30px;

          width=width 30px;=30px;

          border=border 1px=1px solid=solid #fff;=#fff;

          =">

                <linearGradient id="gradmh1" x1="0%" y1="0%" x2="100%" y2="0%">

                  <stop offset="0%" style="stop-color:#c08618;stop-opacity:1"></stop>

                  <stop offset="50%" style="stop-coloR:#fae450;stop-opacity:1"></stop>

				   <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradmh1)" font-size="inherit" font-family="Trajan Pro" x="3" y="34">UNLIMITED ADVICE FOR A FLAT FEE</text>

              UNLIMITED ADVICE FOR A FLAT FEE </svg></h1>

  </div>

  <div id="navbar" class="navbar navbar-inverse navtop">

    <div class="headrin">

      <div class="logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img title="OTH" src="<?php echo get_template_directory_uri(); ?>/images/logo.png"/></a></div>

      <hr class="left-top-line">

      </hr>

      <hr class="left-bottom-line">

      </hr>

      <div class="container menu clearfix"> <span class="treeiconlogo"></span>

        <div class="leftmenu pull-left">

          <ul>

            <li><a href="<?php echo $items1[0]->url; ?>"><svg height="22" width="63">

              <defs style="

          height=height 30px;=30px;

          width=width 30px;=30px;

          border=border 1px=1px solid=solid #fff;=#fff;

          =">

                <linearGradient id="grad1" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#grad1)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[0]->title; ?></text>

              <?php echo $items1[0]->title; ?> </svg></a>

              </li>

            <li><a href="<?php echo $items1[1]->url; ?>"> <svg height="22" width="96">

              <defs style="height: 30px;width=" 30px;border="border: 1px solid;">

                <linearGradient id="grad2" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#grad2)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[1]->title; ?> </text>

              <?php echo $items1[1]->title; ?> </svg> </a></li>

               <li><a href="<?php echo $items1[2]->url; ?>"> <svg height="22" width="86">

              <defs style="height: 30px;width=" 30px;border="border: 1px solid;">

                <linearGradient id="grad3" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#grad3)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[2]->title; ?></text>

              <?php echo $items1[2]->title; ?> </svg> </a></li>

            

           <li><a href="<?php echo $items1[3]->url; ?>"> <svg height="22" width="62">

              <defs style="height: 30px;width=" 30px;border="border: 1px solid;">

                <linearGradient id="grad4" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#grad4)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[3]->title; ?> </text>

              <?php echo $items1[3]->title; ?> </svg> </a></li>

          </ul>

        </div>

        <div class="rightmenu pull-right">

          <ul>

          <li><a href="<?php echo $items2[0]->url; ?>"> <svg height="22" width="78">

              <defs style="height: 30px;width=" 30px;border="border: 1px solid;">

                <linearGradient id="grad5" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#grad5)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[0]->title; ?> </text>

              <?php echo $items2[0]->title; ?> </svg> </a></li>

             <li><a href="<?php echo $items2[1]->url; ?>"> <svg height="22" width="110">

              <defs style="height: 30px;width=" 30px;border="border: 1px solid;">

                <linearGradient id="grad6" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#grad6)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[1]->title; ?> </text>

              <?php echo $items2[1]->title; ?> </svg> </a></li>

               <li><a href="<?php echo $items2[2]->url; ?>"> <svg height="22" width="125">

              <defs style="height: 30px;width=" 30px;border="border: 1px solid;">

                <linearGradient id="grad7" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#grad7)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[2]->title; ?> </text>

              <?php echo $items2[2]->title; ?> </svg> </a></li>

           <li><a href="<?php echo $items2[3]->url; ?>"> <svg height="22" width="93">

              <defs style="height: 30px;width=" 30px;border="border: 1px solid;">

                <linearGradient id="grad8" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#grad8)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[3]->title; ?></text>

              <?php echo $items2[3]->title; ?> </svg> </a></li>

          </ul>

        </div>

      </div>

    </div>

    <h1 class="text-center">

		<svg height="40" width="708">

              <defs style="

          height=height 30px;=30px;

          width=width 30px;=30px;

          border=border 1px=1px solid=solid #fff;=#fff;

          =">

                <linearGradient id="gradh1" x1="0%" y1="0%" x2="100%" y2="0%">

                  <stop offset="0%" style="stop-color:#c08618;stop-opacity:1"></stop>

                  <stop offset="50%" style="stop-coloR:#fae450;stop-opacity:1"></stop>

				   <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradh1)" font-size="inherit" font-family="Trajan Pro" x="3" y="34">UNLIMITED ADVICE FOR A FLAT FEE</text>

              UNLIMITED FOR A FLAT FEE </svg>

   </h1>

  </div>

</header>