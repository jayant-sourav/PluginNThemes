<?php
/*
Template Name: Classes
*/
get_header();
the_post();
?>

<?php
$header_image  = ( get_field('header_image') )?get_field('header_image'):get_stylesheet_directory_uri()."/images/classes-banner.jpg";
$header_title  = ( get_field('header_title') )?get_field('header_title'):'Adult financial  education classes';
$header_subtitle  = ( get_field('header_subtitle') )?get_field('header_subtitle'):'At Affluencer Financial <br />We Focus On Pure Advice <br />And No Sales.';
$header_content = ( get_field('header_content') )?get_field('header_content'):'';
?>

<div class="classes-banner">
	<img src="<?php echo esc_url($header_image); ?>" alt="<?php echo $header_title; ?>" />
    <div class="bannerText"><?php echo $header_title; ?></div>
</div>


<div class="event-calendar">
<div class="container">
<div class="col-md-7 colPad">
<?php echo do_shortcode( '[eo_fullcalendar columnformatmonth="l"]' ); ?>
</div>
      <div class="col-md-5 colPad">
        <div class="calendarEvent">
        <h2>UPCOMING SEMINARS</h2>
        	<div class="content mCustomScrollbar">
                <ul>
                <?php 

                /* Pass these defaults - backwards compat with using eo_get_events()*/
                $query = array(
                    'posts_per_page'   => -1,
                    'post_type'        => 'event',
                    'suppress_filters' => false,
                    'orderby'          => 'eventstart',
                    'order'            => 'ASC',
                    'showrepeats'      => 1,
                    'group_events_by'  => '',
                    'showpastevents'   => false,
                    'no_found_rows'    => false,
                );
                //Make sure false and 'False' etc actually get parsed as 0/false (input from shortcodes, for instance, can be varied).
                //This maybe moved to the shortcode handler if this function is made public.
                if ( 'false' === strtolower( $query['showpastevents'] ) ) {
                    $query['showpastevents'] = 0;
                }
               
                global $eo_event_loop1;
                $eo_event_loop1 = new WP_Query( $query );

                if ( $eo_event_loop1->have_posts() ) {
                    while ( $eo_event_loop1->have_posts() ) {
                        $eo_event_loop1->the_post();
                        ?>
                        <li>
                        <h3><?php the_title(); ?></h3>
                        <div class="calendrEvent">
                            <div class="eventDate">
                            <span class="evntDay"><?php echo eo_get_the_start( 'D' ); ?></span>
                            <span class="evntDate"><?php echo eo_get_the_start( 'j' ); ?></span>
                            </div>
                        
                        <div class="evenntTimeLocation">
                            <span class="EventTime"><?php echo strtoupper(eo_get_the_start('g:i a')); ?> - <?php echo strtoupper(eo_get_the_end('g:i a')); ?></span>
                            <?php $eveaddress = eo_get_venue_address(); ?>
                            <span class="EventLocation"><?php echo $eveaddress['address'];?></span>
                        </div>
                        </div>
                        
                        <div class="eventDetail">
                        <?php the_content(); ?>
                        <?php 
                        $event_contact = get_post_meta( get_the_ID(),'event_contact', true); 
                        $event_email = get_post_meta( get_the_ID(),'event_email', true);
                        $event_phone = get_post_meta( get_the_ID(),'event_phone', true);
                        ?>
                        <div class="eventContact">
                        <?php
                        if( $event_contact != ''){
                            ?>
                            <span><img src="<?php echo get_stylesheet_directory_uri();?>/images/evnt-contact-icon.png" alt="" /> Contact:  <strong><?php echo $event_contact; ?></strong></span>
                            <?php 
                        }
                        if( $event_email != ''){
                            ?>
                            <span><img src="<?php echo get_stylesheet_directory_uri();?>/images/evnt-message-icon.png" alt="" /> Email:  <strong><a href="mailto:<?php echo $event_email; ?>"><?php echo $event_email; ?></a></strong></span>
                            <?php 
                        }
                        if( $event_phone != ''){
                            ?>
                            <span><img src="<?php echo get_stylesheet_directory_uri();?>/images/evnt-phone-icon.png" alt="" /> Phone:  <strong><?php echo $event_phone; ?></strong></span>
                            <?php 
                        } ?>
                        </div>
                        
                        <div class="enroll-here"><a href="<?php the_permalink(); ?>"><span><img src="<?php echo get_stylesheet_directory_uri();?>/images/enroll-icon.png" alt="" /></span> ENROLL HERE</a></div>
                        </div>
                    </li>
                    <?php
                    }
                } elseif ( $no_events ) {
                    ?>
                    <li>
                        <h3>No Events</h3>
                    </li>
                    <?php 
                }
                ?>
                </ul>
                
			</div>
          </div>
      </div>
</div>
</div>


<!-- Put calander Here. -->
<!-- <div class="event-calendar">
	<?php echo do_shortcode( '[eo_fullcalendar]' ); ?>
</div>
 -->



<?php
$class_con_sec_image  = ( get_field('class_con_sec_image') )?get_field('class_con_sec_image'):get_stylesheet_directory_uri()."/images/signup-img.png";
$class_con_sec_title  = ( get_field('class_con_sec_title') )?get_field('class_con_sec_title'):'SEND US A MESSAGE';
?>
<div class="sign-up-herer">
	<div class="container">
    	<div class="signupLeft">
				<img src="<?php echo esc_url($class_con_sec_image); ?>" alt="" />
			</div>
      <div class="signupRight">
      	<h2><?php echo $class_con_sec_title;?></h2>
          <div class="send-mess-area">
          <div class="messa-Box">
				<?php the_field('class_con_sec_content'); ?>
          </div>
          </div>
      </div>
    </div>
</div>

<?php
$class_college_sec_title  = ( get_field('class_college_sec_title') )?get_field('class_college_sec_title'): 'We recruit and hire the most educated and up-to-date associates in the industry.';
$class_college_sec_content  = ( get_field('class_college_sec_content') )?get_field('class_college_sec_content'):'';
?>
<div class="ass-the-industry">
	<div class="container">
    <h2><?php echo $class_college_sec_title; ?></h2>
    <p><?php echo $class_college_sec_content; ?></p>
    </div>
</div>

<?php
	if( have_rows('class_collages') ){
		?>
		<div class="companyDetail">
			<div class="container">
		    <ul>
					<?php
					while ( have_rows('class_collages') ) : the_row();
						$class_col_image = (get_sub_field('class_col_image'))?get_sub_field('class_col_image'): "";
						$class_col_title = (get_sub_field('class_col_title'))?get_sub_field('class_col_title'): "";
						$class_col_content = (get_sub_field('class_col_content'))?get_sub_field('class_col_content'): "";

						if( $class_col_title !=  "" ){
							?>
							<li>
							  <div class="boxContnt">
							    <div class="compnyLogo"><img src="<?php echo esc_url($class_col_image); ?>" alt="<?php echo $class_col_title; ?>" /></div>
							    <h4><?php echo $class_col_title; ?></h4>
							    <?php echo $class_col_content; ?>
							  </div>
							</li>
							<?php
						}
					endwhile;
					?>
				</ul>
		</div>
	</div>
		<?php
	}
?>

<?php
$see_what_others_say_title  = ( get_field('see_what_others_say_title') )?get_field('see_what_others_say_title'): 'SEE WHAT OTHERS SAY';
?>
<div class="see-what-say">
	<div class="container">
    	<h2><?php echo $see_what_others_say_title; ?></h2>
			<?php
			if( have_rows('class_others_say') ){
				echo '<ul>';
				while ( have_rows('class_others_say') ) : the_row();
				$class_video_url = (get_sub_field('class_video_url'))?get_sub_field('class_video_url'):"";
				$video_code	= str_replace( array( 'https://youtube.com/watch?v=', 'https://www.youtube.com/watch?v=', 'http://youtube.com/watch?v=', 'http://www.youtube.com/watch?v=' ), '', $class_video_url);
				if( $video_code !=  "" ){
					?>
						<li>
							<span></span>
							<iframe width="265" height="176" src="https://www.youtube.com/embed/<?php echo $video_code; ?>" frameborder="0" allowfullscreen></iframe>
						</li>
					<?php
				}
				endwhile;
				echo '</ul>';
			}
			?>
    </div>
</div>


<?php //get_sidebar() ?>
<?php get_footer() ?>
