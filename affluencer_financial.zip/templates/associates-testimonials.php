<?php
$asso_testi_sec_title = (get_field('asso_testi_sec_title', get_the_ID()))?get_field('asso_testi_sec_title', get_the_ID()):get_field('asso_testi_sec_title', 'option');
if ($asso_testi_sec_title == ""){
	$asso_testi_sec_title = "<span>WHAT OUR</span> CLIENTS SAY";
}
?>
<div class="clients-say">
	<div class="container">
		<h2><?php echo $asso_testi_sec_title; ?></h2>
		<?php
		if( have_rows('asso_testi_section', get_the_ID()) ){
			echo '<div class="owl-carousel">'; echo "123";
			while ( have_rows('asso_testi_section') ) : the_row();
				$asso_testi_image = (get_sub_field('asso_testi_image', get_the_ID()))?get_sub_field('asso_testi_image', get_the_ID()):'';
				$asso_testi_name = (get_sub_field('asso_testi_name', get_the_ID()))?get_sub_field('asso_testi_name', get_the_ID()):'';
				$asso_testi_position = (get_sub_field('asso_testi_position', get_the_ID()))?get_sub_field('asso_testi_position', get_the_ID()):'';
				$asso_testi_content = (get_sub_field('asso_testi_content', get_the_ID()))?get_sub_field('asso_testi_content', get_the_ID()):'';
				if( $asso_testi_name !=  "" ){
					?>
					<div class="item">
						<div class="client-say-contnt">
							<div class="img"><img src="<?php echo esc_url($asso_testi_image); ?>" /></div>
							<p><?php echo $asso_testi_content; ?></p>
						</div>
						<div class="clientName"><span><?php echo $asso_testi_name; ?></span>
							<?php if( $asso_testi_position != "") {
								echo ' - ' . $asso_testi_position;
							} ?>
						</div>
					</div>
					<?php
				}
			endwhile;
			echo '</div>';
		}else{
			if( have_rows('asso_testi_section', 'options' ) ){
				echo '<div class="owl-carousel">';
				while ( have_rows('asso_testi_section', 'options') ) : the_row();
					$asso_testi_image = (get_sub_field('asso_testi_image', 'options' ))?get_sub_field('asso_testi_image', 'options' ):'';
					$asso_testi_name = (get_sub_field('asso_testi_name', 'options' ))?get_sub_field('asso_testi_name', 'options' ):'';
					$asso_testi_position = (get_sub_field('asso_testi_position', 'options' ))?get_sub_field('asso_testi_position', 'options' ):'';
					$asso_testi_content = (get_sub_field('asso_testi_content', 'options' ))?get_sub_field('asso_testi_content', 'options' ):'';
					if( $asso_testi_name !=  "" ){
						?>
						<div class="item">
							<div class="client-say-contnt">
								<div class="img"><img src="<?php echo esc_url($asso_testi_image); ?>" /></div>
								<p><?php echo $asso_testi_content; ?></p>
							</div>
							<div class="clientName"><span><?php echo $asso_testi_name; ?></span>
								<?php if( $asso_testi_position != "") {
									echo ' - ' . $asso_testi_position;
								} ?>
							</div>
						</div>
						<?php
					}
				endwhile;
				echo '</div>';
			}
		}
		?>
	</div>
</div>

<script>
	jQuery(document).ready( function () {
		jQuery('.owl-carousel').owlCarousel({
			loop:true,
			margin:10,
			nav:true,
			responsive:{
				0:{
					items:1
				},
				600:{
					items:2
				},
				800:{
					items:2
				},
				1000:{
					items:3
				}
			}
		})
	});
</script>