<?php
/*$client_title = (get_field('client_title', get_the_ID()))?get_field('client_title', get_the_ID()):get_field('client_title', 'option');
if ($client_title == ""){
	$client_title = "<span>WHAT OUR</span> CLIENTS SAY?";
}*/
?>
<div class="text-center clientSaybg clientSaybgASS">
	<div class="container">
		<!--<div class="clientSayTitle">
			<h2><?php /*echo $client_title; */?></h2>
		</div>-->
		<div class="clientSay">
			<?php
			if( have_rows('clients_test_videos', get_the_ID()) ){
				echo '<div class="owl-carousel1">';
				while ( have_rows('clients_test_videos') ) : the_row();
					$video_url	= get_sub_field('test_video_url');
					$video_code	= str_replace(array('https://vimeo.com/','https://www.vimeo.com/','http://vimeo.com/','http://www.vimeo.com/'),'',$video_url);
					if( $video_code !=  "" ){
						?>
						<div class="item">
							<div class="clientVideo">
								<iframe style="width:100%;" src="https://player.vimeo.com/video/<?php echo $video_code; ?>?title=0&byline=0&portrait=0" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
							</div>
						</div>
						<?php
					}
				endwhile;
				echo '</div>';
			}else{
				if( have_rows('clients_test_videos', 'options' ) ){
					echo '<div class="owl-carousel1">';
					while ( have_rows('clients_test_videos', 'options') ) : the_row();
						$video_url	= get_sub_field('test_video_url', 'options');
						$video_code	= str_replace(array('https://vimeo.com/','https://www.vimeo.com/','http://vimeo.com/','http://www.vimeo.com/'),'',$video_url);
						if( $video_code !=  "" ){
							?>
							<div class="item">
								<div class="clientVideo">
									<iframe style="width:100%;" src="https://player.vimeo.com/video/<?php echo $video_code; ?>?title=0&byline=0&portrait=0" height="290" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
								</div>
							</div>
							<?php
						}
					endwhile;
					echo '</div>';
				}
			}


			?>

		</div>

	</div>

</div>
<script>
	jQuery(document).ready( function () {
		jQuery('.owl-carousel1').owlCarousel({
			loop:true,
			margin:10,
			nav:true,
			responsive:{
				0:{
					items:1
				},
				600:{
					items:2
				},
				800:{
					items:3
				},
				1000:{
					items:3
				}
			}
		});
	});
</script>
<style>
	.footertoppart {
		background-color: #fff;
	}
</style>