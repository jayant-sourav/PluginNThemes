<?php
$display_call_cta = (get_field('display_call_cta', get_the_ID()))?get_field('display_call_cta', get_the_ID()):get_field('display_call_cta', 'option');
if( $display_call_cta == '1'){

    $call_title = $call_subtitle = $call_mess_button_text = $call_tele_button_text = "";
    $call_mess_button_link = $call_tele_button_link = "";

    $call_title = (get_field('call_title', get_the_ID()))?get_field('call_title', get_the_ID()):get_field('call_title', 'option');
    $call_subtitle = (get_field('call_sub_title', get_the_ID()))?get_field('call_sub_title', get_the_ID()):get_field('call_sub_title', 'option');
    $call_tele_button_text = (get_field('call_tele_button_text', get_the_ID()))?get_field('call_tele_button_text', get_the_ID()):get_field('call_tele_button_text', 'option');
    $call_tele_button_link = (get_field('call_tele_button_link', get_the_ID()))?get_field('call_tele_button_link', get_the_ID()):get_field('call_tele_button_link', 'option');
    $call_mess_button_text = (get_field('call_mess_button_text', get_the_ID()))?get_field('call_mess_button_text', get_the_ID()):get_field('call_mess_button_text', 'option');
    $call_mess_button_link = (get_field('call_mess_button_link', get_the_ID()))?get_field('call_mess_button_link', get_the_ID()):get_field('call_mess_button_link', 'option');

    ?>
    <div class="callNow-area">
        <div class="callNow-Box">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="mobile-img"><img src="<?php echo get_template_directory_uri(); ?>/images/mobile-img.png" alt="" /></div>
                    </div>

                    <div class="col-md-8">
                        <div class="callNow-Text">
                            <h2><?php echo $call_title; ?></h2>
                            <span><?php echo $call_subtitle; ?></span>
                            <div class="Message-Callus">
                                <a href="<?php echo $call_tele_button_link; ?>"><span class="call-icon"></span><?php echo $call_tele_button_text; ?></a>
                                <a href="<?php echo $call_mess_button_link; ?>"><span class="message-icon"></span><?php echo $call_mess_button_text; ?></a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <?php
}
?>