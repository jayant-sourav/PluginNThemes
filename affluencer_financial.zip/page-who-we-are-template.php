<?php
/*
Template Name: Who we are Page
*/
get_header();
the_post();

$who_header_banner = (get_field('who_header_banner'))?get_field('who_header_banner'): get_stylesheet_directory_uri()."/images/who-we-are-banner.jpg";
$who_header_title = (get_field('who_header_title'))?get_field('who_header_title'): "";
$who_header_content = (get_field('who_header_content'))?get_field('who_header_content'): "";
?>
	<div class="whoWeAra-Banner">
		<div class="BannerLeft">
			<div class="bannerImg" style="background: url('<?php echo $who_header_banner; ?>') no-repeat center 0;background-size: cover;height: 520px;">

			</div>
		</div>

		<div class="BannerRight">
			<div class="bannerText">
				<h2><?php echo $who_header_title; ?></h2>
				<p><?php echo $who_header_content; ?></p>
			</div>
		</div>

	</div>

	<div class="who-we-are-content">
	<?php
	if( have_rows('who_sections') ){
		$who_class = array( 'fee-based', 'independent-area', 'objective-area' );
		$who_count = 0 ;
		while ( have_rows('who_sections') ) : the_row();
			$who_sec_image	= get_sub_field('who_sec_image');
			$who_sec_title	= get_sub_field('who_sec_title');
			$who_sec_content= get_sub_field('who_sec_content');
			$who_sec_link	= get_sub_field('who_sec_link');
			$who_current_class = ($who_class[$who_count])?$who_class[$who_count]:"fee-based";
			if( $who_sec_title !=  "" ){
				?>
				<div class="<?php echo $who_current_class; ?>">
					<div class="container">
						<div class="row">
							<?php if( $who_count % 2 == 0 ){
								?>
								<div class="col-sm-4">
									<div class="fee-based-img">
										<img src="<?php echo esc_url($who_sec_image); ?>" alt="" />
									</div>
								</div>
								<?php
							} ?>
							<div class="col-sm-8">
								<div class="fee-based-contnt">
									<h2><?php echo $who_sec_title; ?></h2>
									<p><?php echo $who_sec_content; ?></p>
									<span class="readMore-btn"><a href="<?php echo $who_sec_link; ?>">Read More</a></span>
								</div>
							</div>
							<?php if( $who_count % 2 != 0 ){
								?>
								<div class="col-sm-4">
									<div class="fee-based-img">
										<img src="<?php echo esc_url($who_sec_image); ?>" alt="" />
									</div>
								</div>
								<?php
							} ?>
						</div>
					</div>
				</div>
				<?php
			}
			$who_count++;
		endwhile;
		echo '</div>';
	}
	?>
	</div>

	<?php
	$who_con_title = (get_field('who_con_title'))?get_field('who_con_title'):"<span>OUR EXPERT</span> CONSULTANTS";
	?>
	<div class="ourexpert padB30">
		<div class="container">
			<div class="sectionheadng consultantsTitle text-center">
				<h2><?php echo $who_con_title; ?></h2>
			</div>
			<?php
			if( have_rows('who_consultants_section') ){
				echo '<div class="row text-center finaplanoutermain ourexpertmain">';
				while ( have_rows('who_consultants_section') ) : the_row();
					$who_consub_image	= get_sub_field('who_consub_image');
					$who_consub_title	= get_sub_field('who_consub_title');
					$who_consub_content	= get_sub_field('who_consub_content');
					$who_consub_link	= get_sub_field('who_consub_link');

					if( $who_consub_title !=  "" ){
						?>
						<div class="col-md-4 col-sm-4 col-xs-6 mobilewidth finaplanouter ourexpertcertified">
							<div class="clearfix ourexpertblock">
								<div class="img"> <img src="<?php echo esc_url($who_consub_image); ?>" /></div>
								<h2><?php echo $who_consub_title; ?></h2>
								<p><?php echo $who_consub_content; ?></p>
								<span class="readMore-btn"><a href="<?php echo esc_url($who_consub_link); ?>">Read More</a></span>
							</div>
						</div>
						<?php
					}
				endwhile;
				echo '</div>';
			}
			?>

		</div>
	</div>
	<style>
		.footertoppart {
			background-color: #fff;
		}
	</style>
<?php //get_sidebar() ?>
<?php get_footer() ?>
