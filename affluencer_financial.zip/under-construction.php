<?php
/*
Template Name: Under construction
*/
get_header();

?>
<div  class="container">
<div class="under-img">
	<img src="<?php echo get_field('under-image'); ?>" alt="" class="img responsive" />
</div>
</div>

<?php get_footer() ?>