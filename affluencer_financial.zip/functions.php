<?php
if ( function_exists('register_sidebar') )
	register_sidebar(array(
		'before_widget' => '<div class="blogLinks">',
		'after_widget' => '</div>',
		'before_title' => '<h3>',
		'after_title' => '</h3>',
	));

	register_sidebar( array(
			'name'          => 'Home footer sidebar',
			'id'            => 'home_footer_1'
		) );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'primary'   => __( 'Top primary Left menu', 'affluencer_financial' ),
        'primary-right'   => __( 'Top primary Right menu', 'affluencer_financial' ),
		'secondary' => __( 'Secondary menu in footer', 'affluencer_financial' ),
		'footer' => __( 'Footer menu ', 'affluencer_financial' ),
	) );

add_action('after_setup_theme', 'dharm_theme_setup');

function dharm_theme_setup(){
	//Add theme support for post thumbnail
	add_theme_support( 'post-thumbnails' );
}

// Render Associate Testimonials
function render_associate_client_testimonials(){
	get_template_part( 'templates/associates', 'testimonials');
}

// Render Call Now
function render_call_now_sections(){
	get_template_part( 'templates/section', 'call_now');
}

// Render Footer Video Testimonials
function render_video_testimonials_footer_section(){
	get_template_part( 'templates/section', 'video_testimonials_footer');
}

function wp_get_menu_array($current_menu) {
    $array_menu = wp_get_nav_menu_items($current_menu);
    $menu = array();
    foreach ($array_menu as $m) {
        if (empty($m->menu_item_parent)) {
            $menu[$m->ID] = array();
            $menu[$m->ID]['ID']      =   $m->ID;
            $menu[$m->ID]['title']       =   $m->title;
            $menu[$m->ID]['url']         =   $m->url;
            $menu[$m->ID]['children']    =   array();
        }
    }
    $submenu = array();
    foreach ($array_menu as $m) {
        if ($m->menu_item_parent) {
            $submenu[$m->ID] = array();
            $submenu[$m->ID]['ID']       =   $m->ID;
            $submenu[$m->ID]['title']    =   $m->title;
            $submenu[$m->ID]['url']  =   $m->url;
            $menu[$m->menu_item_parent]['children'][$m->ID] = $submenu[$m->ID];
        }
    }

    return $menu;
}
