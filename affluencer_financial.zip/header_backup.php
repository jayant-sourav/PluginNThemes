<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width">
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<meta name="description" content="<?php bloginfo('description') ?>" />
	<title><?php bloginfo('name'); ?> <?php if ( is_single() ) { ?> &raquo; Blog Archive <?php } ?> <?php wp_title(); ?></title>
	<link href='https://fonts.googleapis.com/css?family=Lato:400,100,100italic,300italic,300,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/pagecss.css">

    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/responsive.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/uikit.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/simpletextrotator.css">

    <!-- Added By Dharmesh Start -->
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/jquery.mCustomScrollbar.css">
    <!-- Added By Dharmesh End -->

	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> Comments RSS Feed" href="<?php bloginfo('comments_rss2_url') ?>"  />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php wp_head() ?>
</head>
<body>
<nav class="pushy pushy-left">
  <ul>
	<?php
		//$items1 = wp_get_nav_menu_items('Main Menu Left');
		$items1 = array_values(wp_get_menu_array('Main Menu Left'));
		$items2 = wp_get_nav_menu_items('Main Menu Right');
		$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	?>
	<li>
		<a href="<?php echo $items1[0]['url']; ?>"><svg height="22" width="63">
              <defs>

                <linearGradient id="gradm1" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm1)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[0]['title']; ?></text>
          <?php echo $items1[0]['title']; ?> </svg>
		</a>
		<?php
			if(count($items1[0]['children']) > 0){
				echo '<ul>';
				
				foreach($items1[0]['children'] AS $key => $val){
					echo '<li><a href="'.$val['url'].'">'.$val['title'].'</a></li>';
				}
				
				echo '</ul>';
			}
		?>
	</li>
	<li>
		<a href="<?php echo $items1[1]['url']; ?>"> <svg height="22" width="96">

              <defs style="height: 30px;widt:30px;border: 1px solid;">

                <linearGradient id="gradm2" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm2)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[1]['title']; ?> </text>

              <?php echo $items1[1]['title']; ?> </svg>
		</a>
		<?php
			if(count($items1[1]['children']) > 0){
				echo '<ul>';
				
				foreach($items1[1]['children'] AS $key => $val){
					echo '<li><a href="'.$val['url'].'">'.$val['title'].'</a></li>';
				}
				
				echo '</ul>';
			}
		?>
	</li>

               <li><a href="<?php echo $items1[2]['url']; ?>"> <svg height="22" width="86">

              <defs>

                <linearGradient id="gradm3" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm3)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[2]['title']; ?></text>

              <?php echo $items1[2]['title']; ?> </svg>
		</a>
		<?php
			if(count($items1[2]['children']) > 0){
				echo '<ul>';
				
				foreach($items1[2]['children'] AS $key => $val){
					echo '<li><a href="'.$val['url'].'">'.$val['title'].'</a></li>';
				}
				
				echo '</ul>';
			}
		?>
	</li>
           <li><a href="<?php echo $items1[3]['url']; ?>"> <svg height="22" width="62">

              <defs>

                <linearGradient id="gradm4" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm4)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[3]['title']; ?> </text>

              <?php echo $items1[3]['title']; ?> </svg>
		</a>
		<?php
			if(count($items1[3]['children']) > 0){
				echo '<ul>';
				
				foreach($items1[3]['children'] AS $key => $val){
					echo '<li><a href="'.$val['url'].'">'.$val['title'].'</a></li>';
				}
				
				echo '</ul>';
			}
		?>
	</li>
	
     <li><a href="<?php echo $items2[0]->url; ?>"> <svg height="22" width="108">

              <defs>

                <linearGradient id="gradm5" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm5)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[0]->title; ?> </text>

              <?php echo $items2[0]->title; ?> </svg> </a></li>

             <li><a href="<?php echo $items2[1]->url; ?>"> <svg height="22" width="110">

              <defs>

                <linearGradient id="gradm6" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm6)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[1]->title; ?> </text>

              <?php echo $items2[1]->title; ?> </svg> </a></li>

               <li><a href="<?php echo $items2[2]->url; ?>"> <svg height="22" width="125">

              <defs>

                <linearGradient id="gradm7" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm7)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[2]->title; ?> </text>

              <?php echo $items2[2]->title; ?> </svg> </a></li>

           <li><a href="<?php echo $items2[3]->url; ?>"> <svg height="22" width="93">

              <defs>

                <linearGradient id="gradm8" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#gradm8)" font-size="inherit" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[3]->title; ?></text>

              <?php echo $items2[3]->title; ?> </svg> </a></li>

	</ul>

</nav>

<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>
<div class="site-overlay"></div>

<header id="top-bar" class="clearfix">

  <div class="mobileheader headrin">

    <div class="logo">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img title="OTH" src="<?php echo get_template_directory_uri(); ?>/images/logo.png"/></a>
		<hr class="left-top-line"></hr>
		<hr class="left-bottom-line"></hr>

    </div>

    <div class="menu-btn"> </div>

    <h1 class="text-center">
		<svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 -5 150 15">
              <defs style="height: 30px;width :30px;border :1px solid #fff;">
                    <linearGradient id="gradmh1" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" style="stop-color:#c08618;stop-opacity:1"></stop>
                        <stop offset="50%" style="stop-coloR:#fae450;stop-opacity:1"></stop>
                        <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>
                    </linearGradient>
                </defs>
              <text fill="url(#gradmh1)" x="75" y="5" text-anchor="middle" font-size="9" font-family="Trajan Pro">
								<?php include_once "title.php"; ?>
							</text>
		</svg>
	</h1>

  </div>

  <div id="navbar" class="navbar navbar-inverse navtop">

    <div class="headrin">
		<div class="logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img title="OTH" src="<?php echo get_template_directory_uri(); ?>/images/logo.png"/></a></div>
		
		<hr class="left-top-line"></hr>
		<hr class="left-bottom-line"></hr>
		<div class="container menu clearfix">
        <div class="leftmenu pull-left">
          <ul>
            <li>
				<?php
					$sub_menu		= '';
					$sub_menu_active= false;
					
					if(count($items1[0]['children']) > 0){
						$sub_menu.= '<ul>';
						
						foreach($items1[0]['children'] AS $key => $val){
							$subactiveclass	= '';
							if($url == $val['url']){
								$subactiveclass	= ' class="active"';
								$sub_menu_active= true;
							}
							$sub_menu.= '<li'.$subactiveclass.'><a href="'.$val['url'].'">'.$val['title'].'</a></li>';
						}
						
						$sub_menu.= '</ul>';
					}
				?>
				<?php
					if($url == $items1[0]['url'] || $sub_menu_active){
					?>
						<span class="treeiconlogo"></span>
					<?php
					}
				?>
				<a href="<?php echo $items1[0]['url']; ?>"><svg height="22" width="63">

              <defs style="

          height=height 30px;=30px;

          width=width 30px;=30px;

          border=border 1px=1px solid=solid #fff;=#fff;

          =">

                <linearGradient id="grad1" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#grad1)" font-size="15" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[0]['title']; ?></text>

              <?php echo $items1[0]['title']; ?> </svg></a>
<?php
			if(count($items1[0]['children']) > 0){
				echo '<ul>';
				
				foreach($items1[0]['children'] AS $key => $val){
					echo '<li><a href="'.$val['url'].'">'.$val['title'].'</a></li>';
				}
				
				echo '</ul>';
			}
		?>
              </li>

            <li>
				<?php
					$sub_menu		= '';
					$sub_menu_active= false;
					
					if(count($items1[1]['children']) > 0){
						$sub_menu.= '<ul>';
						
						foreach($items1[1]['children'] AS $key => $val){
							$subactiveclass	= '';
							if($url == $val['url']){
								$subactiveclass	= ' class="active"';
								$sub_menu_active= true;
							}
							$sub_menu.= '<li'.$subactiveclass.'><a href="'.$val['url'].'">'.$val['title'].'</a></li>';
						}
						
						$sub_menu.= '</ul>';
					}
				?>
				<?php
					if($url == $items1[1]['url'] || $sub_menu_active){
					?>
						<span class="treeiconlogo"></span>
					<?php
					}
				?>
				<a href="<?php echo $items1[1]['url']; ?>"> <svg height="22" width="96">

              <defs>

                <linearGradient id="grad2" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#grad2)" font-size="15" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[1]['title']; ?> </text>

              <?php echo $items1[1]['title']; ?> </svg> </a>
		<?php
			if(count($items1[1]['children']) > 0){
				echo '<ul>';
				
				foreach($items1[1]['children'] AS $key => $val){
					echo '<li><a href="'.$val['url'].'">'.$val['title'].'</a></li>';
				}
				
				echo '</ul>';
			}
		?>
	</li>

               <li>
			   <?php
					$sub_menu		= '';
					$sub_menu_active= false;
					
					if(count($items1[2]['children']) > 0){
						$sub_menu.= '<ul>';
						
						foreach($items1[2]['children'] AS $key => $val){
							$subactiveclass	= '';
							if($url == $val['url']){
								$subactiveclass	= ' class="active"';
								$sub_menu_active= true;
							}
							$sub_menu.= '<li'.$subactiveclass.'><a href="'.$val['url'].'">'.$val['title'].'</a></li>';
						}
						
						$sub_menu.= '</ul>';
					}
				?>
				<?php
					if($url == $items1[2]['url'] || $sub_menu_active){
					?>
						<span class="treeiconlogo"></span>
					<?php
					}
				?>
				<a href="<?php echo $items1[2]['url']; ?>"> <svg height="22" width="82">

              <defs>

                <linearGradient id="grad3" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#grad3)" font-size="15" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[2]['title']; ?></text>

              <?php echo $items1[2]['title']; ?> </svg>
			</a>
			<?php
			if(count($items1[2]['children']) > 0){
				echo '<ul>';
				
				foreach($items1[2]['children'] AS $key => $val){
					echo '<li><a href="'.$val['url'].'">'.$val['title'].'</a></li>';
				}
				
				echo '</ul>';
			}
		?>
		</li>
           <li>
				<?php
					$sub_menu		= '';
					$sub_menu_active= false;
					
					if(count($items1[3]['children']) > 0){
						$sub_menu.= '<ul>';
						
						foreach($items1[3]['children'] AS $key => $val){
							$subactiveclass	= '';
							if($url == $val['url']){
								$subactiveclass	= ' class="active"';
								$sub_menu_active= true;
							}
							$sub_menu.= '<li'.$subactiveclass.'><a href="'.$val['url'].'">'.$val['title'].'</a></li>';
						}
						
						$sub_menu.= '</ul>';
					}
				?>
				<?php
					if($url == $items1[3]['url'] || $sub_menu_active){
					?>
						<span class="treeiconlogo"></span>
					<?php
					}
				?>
				<a href="<?php echo $items1[3]['url']; ?>"> <svg height="22" width="58">

              <defs>

                <linearGradient id="grad4" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#grad4)" font-size="15" font-family="Trajan Pro" x="3" y="16"><?php echo $items1[3]['title']; ?> </text>

              <?php echo $items1[3]['title']; ?> </svg> </a>
			<?php
			if(count($items1[3]['children']) > 0){
				echo '<ul>';
				
				foreach($items1[3]['children'] AS $key => $val){
					echo '<li><a href="'.$val['url'].'">'.$val['title'].'</a></li>';
				}
				
				echo '</ul>';
			}
		?>  
			</li>

          </ul>

        </div>

        <div class="rightmenu pull-right">

          <ul>

          <li>
			<?php
					$sub_right_active= false;
				
					if($url == $items2[0]->url){
				?>
					<span class="treeiconlogo"></span>
				<?php
				}
			?>
				<a href="<?php echo $items2[0]->url; ?>"> <svg height="22" width="110">

              <defs>

                <linearGradient id="grad5" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#grad5)" font-size="15" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[0]->title; ?> </text>

              <?php echo $items2[0]->title; ?> </svg> </a></li>

             <li>
				<?php
					if($url == $items2[1]->url){
					?>
						<span class="treeiconlogo"></span>
					<?php
					}
				?>
			<a href="<?php echo $items2[1]->url; ?>"> <svg height="22" width="74">

              <defs>

                <linearGradient id="grad6" x1="0%" y1="0%" x2="0%" y2="100%">

                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>

                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>

                </linearGradient>

              </defs>

              <text fill="url(#grad6)" font-size="15" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[1]->title; ?> </text>

              <?php echo $items2[1]->title; ?> </svg> </a></li>

               <li>
				<?php
					if($url == $items2[2]->url){
						$sub_right_active= true;
					?>
						<span class="treeiconlogo"></span>
					<?php
					}
				?>
			<a href="<?php echo $items2[2]->url; ?>"> <svg height="22" width="120">
              <defs>
                <linearGradient id="grad7" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>
                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>
                </linearGradient>
              </defs>
              <text fill="url(#grad7)" font-size="15" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[2]->title; ?> </text>
              <?php echo $items2[2]->title; ?> </svg> </a></li>
           <li>
				<?php
					if($url == $items2[3]->url){
						$sub_right_active= true;
				?>
					<span class="treeiconlogo"></span>
				<?php
				}
			?>
			<a href="<?php echo $items2[3]->url; ?>"> <svg height="22" width="93">
              <defs>
                <linearGradient id="grad8" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" style="stop-color:#c9bd30;stop-opacity:1"></stop>
                  <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>
                </linearGradient>
              </defs>
              <text fill="url(#grad8)" font-size="15" font-family="Trajan Pro" x="3" y="16"><?php echo $items2[3]->title; ?></text>
              <?php echo $items2[3]->title; ?> </svg> </a></li>
          </ul>
        </div>
      </div>
		<?php
			$rightClass = ($sub_right_active) ? 'header-call-icon-left' : 'header-call-icon';
		?>
		<a href="tel:310-730-1330" class="<?php echo $rightClass; ?>">
			<?php
				if($rightClass == 'header-call-icon-left'){
			?>
					<span class="call-icon"></span>
					<span class="call-number"> (310) 730-1330</span>
			<?php
				} else {
			?>
					<span class="call-number"> (310) 730-1330</span>
					<span class="call-icon"></span>
			<?php		
				}
			?>
		</a>
	</div>
      <?php
      if( is_singular() && !is_front_page() ){
          $asso_pos = strpos(basename( get_page_template() ), 'page-associates');
          if( $asso_pos !== false ){
              $xt_header_title = __( 'ASSOCIATES', 'xylus' );
          }else{
              if( is_singular( 'post' ) ){
                  $xt_header_title = __( 'Blog', 'xylus' );
              }else{
                  $xt_header_title = get_the_title();
              } 
          }        
      }elseif(is_front_page() && !is_home()){
          $xt_header_title = 'UNLIMITED <div class="rotate">ADVICE,COMFORT,WISDOM,ATTENTION,GUIDANCE,LOVE,INFORMATION,PEACE,COUNSEL,RELIEF,DEDICATION,COMPASSION</div> FOR A FLAT FEE';

      }elseif(!is_front_page() && is_home()){
          $xt_header_title = __( 'Blog', 'xylus' );

      }elseif(is_front_page() && is_home()){
          $xt_header_title = 'UNLIMITED <div class="rotate">ADVICE,COMFORT,WISDOM,ATTENTION,GUIDANCE,LOVE,INFORMATION,PEACE,COUNSEL,RELIEF,DEDICATION,COMPASSION</div> FOR A FLAT FEE';

      }elseif(is_404()){
          $xt_header_title = __( 'Oops! Page Not Found', 'xylus' );

			}elseif(is_archive()){
					
					if(is_author()):
							$xt_header_title = sprintf( __( 'All posts by %s', 'xylus' ), get_the_author() );

					elseif(is_category()):
							$xt_header_title = sprintf( __( 'Category Archives: %s', 'xylus' ), single_cat_title( '', false ) );

					elseif(is_tag()):
							$xt_header_title = sprintf( __( 'Tag Archives: %s', 'xylus' ), single_tag_title( '', false ) );

          elseif( is_day() ) :
							$xt_header_title = sprintf( __( 'Daily Archives: %s', 'xylus' ), get_the_date() );

					elseif ( is_month() ) :
							$xt_header_title = sprintf( __( 'Monthly Archives: %s', 'xylus' ), get_the_date( _x( 'F Y', 'monthly archives date format', 'xylus' ) ) );

					elseif ( is_year() ) :
							$xt_header_title = sprintf( __( 'Yearly Archives: %s', 'xylus' ), get_the_date( _x( 'Y', 'yearly archives date format', 'xylus' ) ) );

					else :
							$xt_header_title =  __( 'Archives', 'xylus' );

					endif;

			} elseif( is_search()){ 
        $xt_header_title = __( 'Search Results', 'xylus' );
			}

      if( (is_front_page() && !is_home()) || is_front_page() && is_home() ){
        ?>
        <h1 class="text-center home-title">UNLIMITED <div class="rotate">SAVING & INVESTMENTS,
FINANCIAL, RETIREMENT, ESTATE</div> FOR A FLAT FEE</h1>
         <?php 
      }else{
        ?>
        <h1 class="text-center" style="text-transform: uppercase;">
            <svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 150 6">
                <defs style="height: 30px;width :30px;border :1px solid #fff;">
                    <linearGradient id="gradh1" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" style="stop-color:#c08618;stop-opacity:1"></stop>
                        <stop offset="50%" style="stop-coloR:#fae450;stop-opacity:1"></stop>
                        <stop offset="100%" style="stop-coloR:#c08618;stop-opacity:1"></stop>
                    </linearGradient>
                </defs>
                <text fill="url(#gradh1)" x="75" y="5" text-anchor="middle" font-size="inherit" font-family="Trajan Pro Bold">
                    <?php
                      echo $xt_header_title;
                    ?>
                </text>
                <?php //echo $xt_header_title; ?>
            </svg>
         </h1>
         <?php 
        } ?>
  </div>
</header>