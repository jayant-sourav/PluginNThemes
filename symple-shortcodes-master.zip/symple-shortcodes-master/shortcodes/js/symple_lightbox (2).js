jQuery(function($){
	$(document).ready(function(){
		$('.symple-shortcodes-lightbox').magnificPopup({
			type: 'image',
			gallery: { enabled: false }
		});
	});
});