<?php
/*
Template Name: Home Page
*/ 
get_header();
the_post();

include_once 'widget-sub-header.php';
?>
<div class="carousel-main">
	<div class="container clearfix">
    	<div class="row">
        	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            	<h1>CLIENT SPOTLIGHT</h1>
                <div id="owl-demo" class="owl-carousel">
					<?php
						$args = array( 'post_type' => 'our-clients', 'posts_per_page' => 6 );
							$loop = new WP_Query( $args );
							$i=0;

							while ( $loop->have_posts() ) : $loop->the_post();
						?>
						<div class="item">
							<div class="caro-img"><img class="lazyOwl" data-src="<?php the_field('image'); ?>" class="member" alt="images"/></div>
							<div class="spotlight_cont">
								<h2><?php the_title(); ?></h2>
								<?php the_content(); ?>
							</div>
						</div>
					<?php
						endwhile;
					?>
					<?php wp_reset_postdata(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
	if( have_rows('about_us_section') ):
		while( have_rows('about_us_section') ): the_row();
	?>
			<div class="about-main">
				<img src="<?php echo get_sub_field('image'); ?>" class="about-img" alt="<?php echo get_sub_field('title'); ?>" />
				<div class="container clearfix">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="about">
								<img src="<?php bloginfo('template_url'); ?>/images/triangle-white.png" class="triangle-white" alt="about" />
								<div class="about-text">
									<h1><?php echo get_sub_field('title'); ?></h1>
									<?php echo get_sub_field('detail'); ?>
									<p class="mobile-rev-btn"><a href="<?php echo get_sub_field('url'); ?>" class="button">MEET THE FAMILY</a></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
	<?php
		endwhile;
	endif;
?>
<!--start seperator-->
<div class="seperator-main">
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 left-div">
            <div>&nbsp;</div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 right-div">
            <div>&nbsp;</div>
        </div>
    </div>
</div>            
<!--end seperator-->
<div class="neighbour-main">
	<div class="container clearfix">
    	<div class="row">
        	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="neighbour-text">
                	<h1>NEIGHBORHOODS</h1>                    
                </div>
            </div>
		</div>
    </div>
    <div class="location-map">
    	<img src="<?php bloginfo('template_url'); ?>/images/neighbour.jpg" class="neighbour-img" alt="neighbour" />
    </div>
</div>
<?php include_once 'widget-listings.php'; ?>
<div class="blog-main"><img src="<?php bloginfo('template_url'); ?>/images/triangle-white.png" class="triangle-white" alt="triangle" />
	<div class="container clearfix">
    	<div class="row">
        	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            	
                <h1>LATEST BLOG POST</h1>
                <div class="neighbour-text">
                	
                </div>
            </div>
		</div>
    </div>
    <div class="blog-blending"> &nbsp; </div>
	<div class="container clearfix">
    	<div class="our-blog">
            <div class="blog-contents">
				<?php
					$args = array(
						'numberposts' => 1,
						'offset' => 0,
						'category' => 0,
						'orderby' => 'post_date',
						'order' => 'DESC',
						'include' => '',
						'exclude' => '',
						'meta_key' => '',
						'meta_value' =>'',
						'post_type' => 'post',
						'post_status' => 'draft, publish, future, pending, private',
						'suppress_filters' => true
					);

					$recent_posts = wp_get_recent_posts( $args, ARRAY_A );
					
					$url = get_field('image',$recent_posts[0]["ID"]);
					
					if($url == ''){
						$post_thumbnail_id = get_post_thumbnail_id( $recent_posts[0]["ID"] ); 
						$url=wp_get_attachment_image_src($post_thumbnail_id);
					}
				?>
                <h2><?php echo $recent_posts[0]["post_title"]; ?></h2>
                <div class="sub-title"><strong><?php the_field('sub_title',$recent_posts[0]["ID"]); ?></strong></div>
                <p><?php echo wp_trim_words($recent_posts[0]["post_content"],60,' <a href="'.get_permalink($recent_posts[0]["ID"]).'">read more...</a>'); ?></p>
                <img src="<?php echo $url; ?>" class="blog-img" alt="blog-img" />   
            </div>
        </div>
		<?php wp_reset_query(); ?>
        <div class="blog-btn"><a href="<?php echo esc_url( home_url( '/' ) ); ?>the-blog" class="button">OUR BLOG</a></div>
    </div>
</div>
<?php get_footer() ?>